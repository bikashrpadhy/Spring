package pivotrics.bikash.myproduct.data.entity.promo;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serial;
import java.io.Serializable;

@Getter
@Setter
//@NoArgsConstructor
//@AllArgsConstructor
@Entity
@Table(name = "product_group_criteria")
public class Product_group_criteria implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @Column(name = "enable_min_quantity_check")
    private Boolean enableMinQuantityCheck;

    @Column(name = "enable_min_product_variety_check")
    private Boolean enableMinProductVarietyCheck;

    @Column(name = "min_quantity")
    private Short minQuantity;

    @Column(name = "min_product_variety")
    private Short minProductVariety;

    @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "id_merchant_product_group_id", unique = true)
    private Merchant_product_group merchant_product_group;

    // bidirectional one to one mapping with merchant product group
//    @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
//    @JoinColumn(name = "id_merchant_product_group", unique = true)
//    private Merchant_product_group merchantProductGroup;

}