package pivotrics.bikash.myproduct.api.mapper.promo;

import org.springframework.data.jpa.repository.JpaRepository;
import pivotrics.bikash.myproduct.data.entity.promo.Product_group_criteria;

public interface ProductGroupCriteriaRepository extends JpaRepository<Product_group_criteria, Integer> {
    // Custom query methods can be added here if needed
}
