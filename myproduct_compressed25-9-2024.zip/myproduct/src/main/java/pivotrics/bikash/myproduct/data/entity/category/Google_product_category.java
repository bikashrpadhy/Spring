package pivotrics.bikash.myproduct.data.entity.category;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serial;
import java.io.Serializable;

@Getter
@Setter
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "google_product_category")
public class Google_product_category implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @Column(name = "name")
    private String name;

    @Column(name = "isEnabled")
    private Boolean isEnabled;

    @Column(name = "merchantAccountNumber")
    private Integer merchantAccountNumber;

    @ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(name = "googleParentCategory")
    private Google_product_category googleParentCategory; // it's a foreign key from one entity-instance to another
    // it's basically an integer

    @Column(name = "level")
    private Short level;

    @Column(name = "categoryCode")
    private Short categoryCode;

    @Column(name = "fullQualifiedName")
    private String fullQualifiedName;

}