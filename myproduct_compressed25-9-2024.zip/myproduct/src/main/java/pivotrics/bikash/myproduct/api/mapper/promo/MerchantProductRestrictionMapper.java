package pivotrics.bikash.myproduct.api.mapper.promo;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;
import pivotrics.bikash.myproduct.api.dto.MerchantProductRestrictionDto;
import pivotrics.bikash.myproduct.data.entity.promo.Merchant_product_restriction;

@Mapper(componentModel = "spring")
public interface MerchantProductRestrictionMapper {
    MerchantProductRestrictionMapper INSTANCE = Mappers.getMapper(MerchantProductRestrictionMapper.class);

//    @Mapping(source = "merchantProduct.id", target = "merchantProduct") // Map the entity reference back to ID
//    @Mapping(source = "merchantProductGroup", target= "merchantProductGroup.id")
    Merchant_product_restriction toEntity(MerchantProductRestrictionDto dto);

//    @Mapping(target = "merchantProductGroup", source= "merchantProductGroup.id")
    MerchantProductRestrictionDto toDto(Merchant_product_restriction entity);
}
