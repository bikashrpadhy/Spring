// working
package pivotrics.bikash.myproduct.api.controller.product;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pivotrics.bikash.myproduct.api.dto.MerchantProductDto;
import pivotrics.bikash.myproduct.data.service.product.MerchantProductService;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/merchant-products")
@RequiredArgsConstructor
public class MerchantProductController {
    private final MerchantProductService service;

    @PostMapping
    public ResponseEntity<MerchantProductDto> create(@RequestBody MerchantProductDto dto) {
        log.info("Creating Merchant Product: {}", dto);
        MerchantProductDto createdDto = service.create(dto);
        return new ResponseEntity<>(createdDto, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<MerchantProductDto>> getAll() {
        log.info("Fetching all Merchant Products");
        List<MerchantProductDto> dtos = service.getAll();
        return new ResponseEntity<>(dtos, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<MerchantProductDto> getById(@PathVariable Integer id) {
        log.info("Fetching Merchant Product by ID: {}", id);
        MerchantProductDto dto = service.getById(id);
        return dto != null ? new ResponseEntity<>(dto, HttpStatus.OK) : ResponseEntity.notFound().build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<MerchantProductDto> update(@PathVariable Integer id, @RequestBody MerchantProductDto dto) {
        log.info("Updating Merchant Product ID: {} with data: {}", id, dto);
        MerchantProductDto updatedDto = service.update(id, dto);
        return new ResponseEntity<>(updatedDto, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Integer id) {
        log.info("Deleting Merchant Product ID: {}", id);
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
