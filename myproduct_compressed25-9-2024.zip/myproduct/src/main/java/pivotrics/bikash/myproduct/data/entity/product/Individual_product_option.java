package pivotrics.bikash.myproduct.data.entity.product;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serial;
import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "individual_product_option")
public class Individual_product_option implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @Column(name = "name")
    private String name;

    @Column(name = "value")
    private String value;

    @ManyToOne(cascade = {CascadeType.DETACH})
    @JoinColumn(name = "id_merchantProducts")
    private Merchant_products merchantProduct;

    @ManyToOne(cascade = CascadeType.DETACH)
    @JoinColumn(name = "id_productOption")
    private Product_option productOption;

}