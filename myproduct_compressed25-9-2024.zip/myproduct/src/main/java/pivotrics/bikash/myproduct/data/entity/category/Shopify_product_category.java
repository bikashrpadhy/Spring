package pivotrics.bikash.myproduct.data.entity.category;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import pivotrics.bikash.myproduct.data.entity.product.Merchant_products;

import java.io.Serial;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "shopify_product_category")
public class Shopify_product_category implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @Column(name = "name")
    private String name;

    @Column(name = "isEnabled")
    private Boolean isEnabled;

    @Column(name = "merchantAccountNumber")
    private Integer merchantAccountNumber;

    @Column(name = "level")
    private Short level;

    @Column(name = "categoryCode")
    private Short categoryCode;

    @Column(name = "fullQualifiedName")
    private String fullQualifiedName;

    @ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(name = "parent_id")
    private Shopify_product_category shopifyParentCategory;

}