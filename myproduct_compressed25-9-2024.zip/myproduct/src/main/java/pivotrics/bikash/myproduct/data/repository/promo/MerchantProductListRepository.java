package pivotrics.bikash.myproduct.data.repository.promo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import pivotrics.bikash.myproduct.data.entity.promo.Merchant_product_list;

@Repository
public interface MerchantProductListRepository extends JpaRepository<Merchant_product_list, Integer> {
    // Custom query methods can be added here if needed
}
