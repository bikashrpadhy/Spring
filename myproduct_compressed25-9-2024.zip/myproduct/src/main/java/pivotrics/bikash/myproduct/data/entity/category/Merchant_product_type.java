package pivotrics.bikash.myproduct.data.entity.category;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import pivotrics.bikash.myproduct.data.entity.product.Merchant_products;

import java.io.Serial;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
//@EqualsAndHashCode
@Entity
@Table(name = "merchant_product_type")
public class Merchant_product_type implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @Column(name = "name")
    private String name;

    @Column(name = "merchant_account_number", nullable = false)
    private Integer merchantAccountNumber;

//    @OneToMany(mappedBy = "id_merchant_product_type", cascade = CascadeType.ALL, orphanRemoval = true)
//    private List<Merchant_products> merchantProducts = new ArrayList<>();


}