package pivotrics.bikash.myproduct.data.service.promo;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import pivotrics.bikash.myproduct.api.dto.MerchantProductRestrictionDto;
import pivotrics.bikash.myproduct.api.mapper.promo.MerchantProductRestrictionMapper;
import pivotrics.bikash.myproduct.data.entity.promo.Merchant_product_restriction;
import pivotrics.bikash.myproduct.data.repository.promo.MerchantProductRestrictionRepository;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class MerchantProductRestrictionService {
    private final MerchantProductRestrictionRepository repository;
    private final MerchantProductRestrictionMapper mapper;

    @Transactional
    public MerchantProductRestrictionDto create(MerchantProductRestrictionDto dto) {
        log.info("Creating Merchant Product Restriction: {}", dto);
        Merchant_product_restriction entity = mapper.toEntity(dto);
        entity = repository.save(entity);
        return mapper.toDto(entity);
    }

    @Transactional(readOnly = true)
    public List<MerchantProductRestrictionDto> getAll() {
        log.info("Fetching all Merchant Product Restrictions");
        return repository.findAll().stream()
                .map(mapper::toDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public MerchantProductRestrictionDto getById(Integer id) {
        log.info("Fetching Merchant Product Restriction by ID: {}", id);
        return repository.findById(id)
                .map(mapper::toDto)
                .orElse(null); // Handle not found as needed
    }

    @Transactional
    public MerchantProductRestrictionDto update(Integer id, MerchantProductRestrictionDto dto) {
        log.info("Updating Merchant Product Restriction ID: {} with data: {}", id, dto);
        Merchant_product_restriction existingEntity = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Merchant Product Restriction not found")); // Handle not found

        existingEntity.setRestrictionName(dto.getRestrictionName());
        existingEntity.setRestrictionDescription(dto.getRestrictionDescription());
        existingEntity.setLastUpdated(dto.getLastUpdated());
        existingEntity.setIsEnabled(dto.getIsEnabled());
        existingEntity.setMerchantAccountNumber(dto.getMerchantAccountNumber());

        existingEntity = repository.save(existingEntity);
        return mapper.toDto(existingEntity);
    }

    @Transactional
    public void delete(Integer id) {
        log.info("Deleting Merchant Product Restriction ID: {}", id);
        if (!repository.existsById(id)) {
            throw new RuntimeException("Merchant Product Restriction not found"); // Handle not found
        }
        repository.deleteById(id);
    }
}
