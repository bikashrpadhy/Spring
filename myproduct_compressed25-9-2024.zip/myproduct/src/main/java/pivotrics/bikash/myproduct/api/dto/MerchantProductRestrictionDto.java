package pivotrics.bikash.myproduct.api.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.ZonedDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class MerchantProductRestrictionDto {
    private Integer id;
    private String restrictionName;
    private String restrictionDescription;
    private ZonedDateTime lastUpdated;
    private Boolean isEnabled;
    private Integer merchantAccountNumber;

    // You can add other fields as needed, such as restricted product list
}

