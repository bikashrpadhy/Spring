package pivotrics.bikash.myproduct.data.repository.product;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import pivotrics.bikash.myproduct.data.entity.product.Merchant_tax_config;

@Repository
public interface MerchantTaxConfigRepository extends JpaRepository<Merchant_tax_config, Integer> {
    // Custom query methods (if needed) can be defined here
}
