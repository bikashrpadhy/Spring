package pivotrics.bikash.myproduct.data.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import pivotrics.bikash.myproduct.api.dto.MerchantCatalogConfigDto;
import pivotrics.bikash.myproduct.api.mapper.MerchantCatalogConfigMapper;
import pivotrics.bikash.myproduct.data.entity.Merchant_catalog_config;
import pivotrics.bikash.myproduct.data.entity.enums.merchant_product_category_choice;
import pivotrics.bikash.myproduct.data.repository.MerchantCatalogConfigRepository;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class MerchantCatalogConfigService {
    private final MerchantCatalogConfigRepository repository;
    private final MerchantCatalogConfigMapper mapper;

    @Transactional
    public MerchantCatalogConfigDto create(MerchantCatalogConfigDto dto) {
        log.info("Creating Merchant Catalog Config: {}", dto);
        Merchant_catalog_config entity = mapper.toEntity(dto);
        entity = repository.save(entity);
        return mapper.toDto(entity);
    }

    @Transactional(readOnly = true)
    public List<MerchantCatalogConfigDto> getAll() {
        log.info("Fetching all Merchant Catalog Configs");
        return repository.findAll().stream()
                .map(mapper::toDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public MerchantCatalogConfigDto getById(Integer id) {
        log.info("Fetching Merchant Catalog Config by ID: {}", id);
        return repository.findById(id)
                .map(mapper::toDto)
                .orElse(null); // Handle not found as needed
    }

    @Transactional
    public MerchantCatalogConfigDto update(Integer id, MerchantCatalogConfigDto dto) {
        log.info("Updating Merchant Catalog Config ID: {} with data: {}", id, dto);
        Merchant_catalog_config existingEntity = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Merchant Catalog Config not found")); // Handle not found

        // Update fields from DTO to entity
        mapper.toEntity(dto); // This line is for demonstration; you might want to map fields explicitly
        existingEntity.setMerchantAccountNumber(dto.getMerchantAccountNumber());
        existingEntity.setMaxAllowedProduct(dto.getMaxAllowedProduct());
        existingEntity.setMaxAllowedType(dto.getMaxAllowedType());
        existingEntity.setCategoriesChoice(merchant_product_category_choice.valueOf(dto.getCategoriesChoice()));

        existingEntity.setMaxAllowedProductLists(dto.getMaxAllowedProductLists());
        existingEntity.setMaxAllowedEnabledProductLists(dto.getMaxAllowedEnabledProductLists());
        existingEntity.setMaxAllowedProductsInProductList(dto.getMaxAllowedProductsInProductList());
        existingEntity.setMaxAllowedProductGroup(dto.getMaxAllowedProductGroup());
        existingEntity.setMaxAllowedEnabledProductGroups(dto.getMaxAllowedEnabledProductGroups());
        existingEntity.setMaxCategoriesInProductGroup(dto.getMaxCategoriesInProductGroup());
        existingEntity.setMaxProductTypesInProductGroup(dto.getMaxProductTypesInProductGroup());
        existingEntity.setMaxProductsInComboProductGroup(dto.getMaxProductsInComboProductGroup());
        existingEntity.setMaxIndividualProductsInProductGroup(dto.getMaxIndividualProductsInProductGroup());

        existingEntity = repository.save(existingEntity);
        return mapper.toDto(existingEntity);
    }

    @Transactional
    public void delete(Integer id) {
        log.info("Deleting Merchant Catalog Config ID: {}", id);
        if (!repository.existsById(id)) {
            throw new RuntimeException("Merchant Catalog Config not found"); // Handle not found
        }
        repository.deleteById(id);
    }
}
