package pivotrics.bikash.myproduct.data.repository.promo;

import org.springframework.data.jpa.repository.JpaRepository;
import pivotrics.bikash.myproduct.data.entity.promo.Product_group_limiting_factors;

public interface ProductGroupLimitingFactorsRepository extends JpaRepository<Product_group_limiting_factors, Integer> {
    // Custom query methods can be added here if needed
}
