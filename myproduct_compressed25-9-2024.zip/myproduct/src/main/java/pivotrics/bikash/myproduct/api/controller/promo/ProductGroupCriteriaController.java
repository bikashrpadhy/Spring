// working
package pivotrics.bikash.myproduct.api.controller.promo;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pivotrics.bikash.myproduct.api.dto.ProductGroupCriteriaDto;
import pivotrics.bikash.myproduct.data.service.promo.ProductGroupCriteriaService;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/product-group-criteria")
@RequiredArgsConstructor
public class ProductGroupCriteriaController {
    private final ProductGroupCriteriaService service;

    @PostMapping
    public ResponseEntity<ProductGroupCriteriaDto> create(@RequestBody ProductGroupCriteriaDto dto) {
        log.info("Creating Product Group Criteria: {}", dto);
        ProductGroupCriteriaDto createdDto = service.create(dto);
        return new ResponseEntity<>(createdDto, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<ProductGroupCriteriaDto>> getAll() {
        log.info("Fetching all Product Group Criteria");
        List<ProductGroupCriteriaDto> dtos = service.getAll();
        return new ResponseEntity<>(dtos, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ProductGroupCriteriaDto> getById(@PathVariable Integer id) {
        log.info("Fetching Product Group Criteria by ID: {}", id);
        ProductGroupCriteriaDto dto = service.getById(id);
        return dto != null ? new ResponseEntity<>(dto, HttpStatus.OK) : ResponseEntity.notFound().build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<ProductGroupCriteriaDto> update(@PathVariable Integer id, @RequestBody ProductGroupCriteriaDto dto) {
        log.info("Updating Product Group Criteria ID: {} with data: {}", id, dto);
        ProductGroupCriteriaDto updatedDto = service.update(id, dto);
        return new ResponseEntity<>(updatedDto, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Integer id) {
        log.info("Deleting Product Group Criteria ID: {}", id);
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
