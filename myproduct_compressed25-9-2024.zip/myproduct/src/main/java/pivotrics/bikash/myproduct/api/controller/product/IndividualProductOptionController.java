// working
package pivotrics.bikash.myproduct.api.controller.product;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import pivotrics.bikash.myproduct.api.dto.IndividualProductOptionDto;
import pivotrics.bikash.myproduct.data.service.product.IndividualProductOptionService;


import java.util.List;

@Slf4j
@RestController
@RequestMapping("/individual-product-options")
@RequiredArgsConstructor
public class IndividualProductOptionController {

    private final IndividualProductOptionService optionService;

    @PostMapping
    public ResponseEntity<IndividualProductOptionDto> createOption(@RequestBody IndividualProductOptionDto dto) {
        log.info("Creating new IndividualProductOption");
        IndividualProductOptionDto createdOption = optionService.createOption(dto);
        return ResponseEntity.ok(createdOption);
    }

    @GetMapping
    public ResponseEntity<List<IndividualProductOptionDto>> getAllOptions() {
        log.info("Fetching all IndividualProductOptions");
        List<IndividualProductOptionDto> options = optionService.getAllOptions();
        return ResponseEntity.ok(options);
    }

    @GetMapping("/{id}")
    public ResponseEntity<IndividualProductOptionDto> getOptionById(@PathVariable Integer id) {
        log.info("Fetching IndividualProductOption with ID: {}", id);
        IndividualProductOptionDto option = optionService.getOptionById(id);
        return ResponseEntity.ok(option);
    }

    @PutMapping("/{id}")
    public ResponseEntity<IndividualProductOptionDto> updateOption(@PathVariable Integer id,
                                                                   @RequestBody IndividualProductOptionDto dto) {
        log.info("Updating IndividualProductOption with ID: {}", id);
        IndividualProductOptionDto updatedOption = optionService.updateOption(id, dto);
        return ResponseEntity.ok(updatedOption);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteOption(@PathVariable Integer id) {
        log.info("Deleting IndividualProductOption with ID: {}", id);
        optionService.deleteOption(id);
        return ResponseEntity.noContent().build();
    }
}
