package pivotrics.bikash.myproduct.data.service.category;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import pivotrics.bikash.myproduct.api.dto.ShopifyProductCategoryDto;
import pivotrics.bikash.myproduct.data.entity.category.Shopify_product_category;
import pivotrics.bikash.myproduct.data.repository.category.ShopifyProductCategoryRepository;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ShopifyProductCategoryService {

    private static final Logger logger = LoggerFactory.getLogger(ShopifyProductCategoryService.class);

    @Autowired
    private ShopifyProductCategoryRepository repository;

    @Autowired
    private ModelMapper modelMapper;

    @Transactional
    public ShopifyProductCategoryDto createCategory(ShopifyProductCategoryDto dto) {
        logger.info("Creating Shopify Product Category: {}", dto);
        Shopify_product_category entity = modelMapper.map(dto, Shopify_product_category.class);

        if (dto.getShopifyParentCategory() != null) {
            Shopify_product_category parent = repository.findById(dto.getShopifyParentCategory())
                    .orElseThrow(() -> new RuntimeException("Parent Category not found with id " + dto.getShopifyParentCategory()));
            entity.setShopifyParentCategory(parent);
        }

        Shopify_product_category savedEntity = repository.save(entity);
        return modelMapper.map(savedEntity, ShopifyProductCategoryDto.class);
    }

    public List<ShopifyProductCategoryDto> getAllCategories() {
        logger.info("Fetching all Shopify Product Categories");
        return repository.findAll().stream()
                .map(entity -> modelMapper.map(entity, ShopifyProductCategoryDto.class))
                .collect(Collectors.toList());
    }

    public ShopifyProductCategoryDto getCategoryById(Integer id) {
        logger.info("Fetching Shopify Product Category with id: {}", id);
        Shopify_product_category entity = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Category not found with id " + id));
        return modelMapper.map(entity, ShopifyProductCategoryDto.class);
    }

    @Transactional
    public ShopifyProductCategoryDto updateCategory(Integer id, ShopifyProductCategoryDto dto) {
        logger.info("Updating Shopify Product Category with id: {}", id);
        if (repository.existsById(id)) {
            dto.setId(id);
            Shopify_product_category entity = modelMapper.map(dto,Shopify_product_category.class);

            if (dto.getShopifyParentCategory() != null) {
                Shopify_product_category parent = repository.findById(dto.getShopifyParentCategory())
                        .orElseThrow(() -> new RuntimeException("Parent Category not found with id " + dto.getShopifyParentCategory()));
                entity.setShopifyParentCategory(parent);
            }

            Shopify_product_category updatedEntity = repository.save(entity);
            return modelMapper.map(updatedEntity, ShopifyProductCategoryDto.class);
        } else {
            throw new RuntimeException("Category not found with id " + id);
        }
    }

    @Transactional
    public void deleteCategory(Integer id) {
        try {
            logger.info("Deleting Shopify Product Category with id: {}", id);
            Shopify_product_category parentCategory = repository.findById(id)
                    .orElseThrow(() -> new RuntimeException("Parent Category not found with id " + id));

            // Find all child entities where parentId = categoryId
            List<Shopify_product_category> children = repository.findByshopifyParentCategory(parentCategory);

            // Disassociate each child from the parent
            for (Shopify_product_category child : children) {
                child.setShopifyParentCategory(null);
                repository.save(child);  // Update the child entity to remove parent reference
            }

            repository.deleteById(id);
        } catch (Exception e) {
            logger.error("Failed to delete Shopify Product Category with id: {}. It does not exist.", id);
            throw new RuntimeException("Category not found with id " + id);
        }
    }
}
