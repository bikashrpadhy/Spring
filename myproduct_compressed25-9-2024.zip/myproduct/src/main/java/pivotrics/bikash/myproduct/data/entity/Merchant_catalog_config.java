package pivotrics.bikash.myproduct.data.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import pivotrics.bikash.myproduct.data.entity.enums.merchant_product_category_choice;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "merchant_catalog_config")
public class Merchant_catalog_config {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @Column(name = "merchantAccountNumber")
    private Integer merchantAccountNumber;

    @Column(name = "maxAllowedProduct")
    private Short maxAllowedProduct;

    @Column(name = "maxAllowedType")
    private Short maxAllowedType;

    @Enumerated(EnumType.STRING)
    @Column(name = "merchant_product_category_choice")
    private merchant_product_category_choice categoriesChoice;

    @Column(name = "maxAllowedProductLists")
    private Short maxAllowedProductLists;

    @Column(name = "maxAllowedEnabledProductLists")
    private Short maxAllowedEnabledProductLists;

    @Column(name = "maxAllowedProductsInProductList")
    private Short maxAllowedProductsInProductList;

    @Column(name = "maxAllowedProductGroup")
    private Short maxAllowedProductGroup;

    @Column(name = "maxAllowedEnabledProductGroups")
    private Short maxAllowedEnabledProductGroups;

    @Column(name = "maxCategoriesInProductGroup")
    private Short maxCategoriesInProductGroup;

    @Column(name = "maxProductTypesInProductGroup")
    private Short maxProductTypesInProductGroup;

    @Column(name = "maxProductsInComboProductGroup")
    private Short maxProductsInComboProductGroup;

    @Column(name = "maxIndividualProductsInProductGroup")
    private Short maxIndividualProductsInProductGroup;


}