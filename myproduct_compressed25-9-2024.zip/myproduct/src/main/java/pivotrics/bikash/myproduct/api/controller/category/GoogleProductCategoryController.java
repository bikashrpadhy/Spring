package pivotrics.bikash.myproduct.api.controller.category;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import pivotrics.bikash.myproduct.api.dto.GoogleProductCategoryDto;
import pivotrics.bikash.myproduct.data.service.category.GoogleProductCategoryService;

import java.util.List;

@RestController
@RequestMapping("/google-product-categories")
@RequiredArgsConstructor
@Slf4j
public class GoogleProductCategoryController {

    private final GoogleProductCategoryService categoryService;

    @PostMapping
    public ResponseEntity<GoogleProductCategoryDto> createCategory(@RequestBody GoogleProductCategoryDto categoryDto) {
        log.info("Request to create GoogleProductCategory");
        GoogleProductCategoryDto createdCategory = categoryService.createCategory(categoryDto);
        return ResponseEntity.ok(createdCategory);
    }

    @PutMapping("/{id}")
    public ResponseEntity<GoogleProductCategoryDto> updateCategory(
            @PathVariable Integer id, @RequestBody GoogleProductCategoryDto categoryDto) {
        log.info("Request to update GoogleProductCategory with ID: {}", id);
        GoogleProductCategoryDto updatedCategory = categoryService.updateCategory(id, categoryDto);
        return ResponseEntity.ok(updatedCategory);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCategory(@PathVariable Integer id) {
        log.info("Request to delete GoogleProductCategory with ID: {}", id);
        categoryService.deleteCategory(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{id}")
    public ResponseEntity<GoogleProductCategoryDto> getCategoryById(@PathVariable Integer id) {
        log.info("Request to get GoogleProductCategory with ID: {}", id);
        GoogleProductCategoryDto category = categoryService.getCategoryById(id);
        return ResponseEntity.ok(category);
    }

    @GetMapping
    public ResponseEntity<List<GoogleProductCategoryDto>> getAllCategories() {
        log.info("Request to get all GoogleProductCategories");
        List<GoogleProductCategoryDto> categories = categoryService.getAllCategories();
        return ResponseEntity.ok(categories);
    }
}
