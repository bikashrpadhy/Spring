package pivotrics.bikash.myproduct.api.dto;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.time.ZonedDateTime;

@Getter
@Setter
public class MerchantProductBrandDto implements Serializable {
    private static final long serialVersionUID = 1L;

    private Integer id;
    private Boolean brandCollaborationFlag;
    private String brandName;
    private String description;
    private Boolean isEnabled;
    private ZonedDateTime createdOn;
    private ZonedDateTime lastUpdated;
    private Integer merchantAccountNumber;

    // getters and setters
}