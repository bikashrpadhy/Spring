package pivotrics.bikash.myproduct.data.repository.product;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import pivotrics.bikash.myproduct.data.entity.product.Product_option;

@Repository
public interface ProductOptionRepository extends JpaRepository<Product_option, Integer> {
    // Add custom query methods if needed
}
