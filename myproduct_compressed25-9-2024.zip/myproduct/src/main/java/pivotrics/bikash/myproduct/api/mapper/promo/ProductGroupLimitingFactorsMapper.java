package pivotrics.bikash.myproduct.api.mapper.promo;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;
import pivotrics.bikash.myproduct.api.dto.ProductGroupLimitingFactorDto;
import pivotrics.bikash.myproduct.data.entity.promo.Product_group_limiting_factors;

@Mapper(componentModel = "spring")
public interface ProductGroupLimitingFactorsMapper {
    ProductGroupLimitingFactorsMapper INSTANCE = Mappers.getMapper(ProductGroupLimitingFactorsMapper.class);

    @Mapping(source= "merchantProductGroup", target = "merchantProductGroup.id")
    Product_group_limiting_factors toEntity(ProductGroupLimitingFactorDto dto);

    @Mapping(target= "merchantProductGroup", source = "merchantProductGroup.id")
    ProductGroupLimitingFactorDto toDto(Product_group_limiting_factors entity);
}

