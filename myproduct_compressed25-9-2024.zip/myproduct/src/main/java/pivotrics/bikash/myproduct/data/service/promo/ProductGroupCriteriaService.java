package pivotrics.bikash.myproduct.data.service.promo;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import pivotrics.bikash.myproduct.api.dto.ProductGroupCriteriaDto;
import pivotrics.bikash.myproduct.api.mapper.promo.ProductGroupCriteriaMapper;
import pivotrics.bikash.myproduct.api.mapper.promo.ProductGroupCriteriaRepository;
import pivotrics.bikash.myproduct.data.entity.product.Merchant_products;
import pivotrics.bikash.myproduct.data.entity.promo.Merchant_product_group;
import pivotrics.bikash.myproduct.data.entity.promo.Product_group_criteria;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class ProductGroupCriteriaService {
    private final ProductGroupCriteriaRepository repository;
    private final ProductGroupCriteriaMapper mapper;

    @Transactional
    public ProductGroupCriteriaDto create(ProductGroupCriteriaDto dto) {
        log.info("Creating Product Group Criteria: {}", dto);
        Product_group_criteria entity = mapper.toEntity(dto);
        entity = repository.save(entity);
        return mapper.toDto(entity);
    }

    @Transactional(readOnly = true)
    public List<ProductGroupCriteriaDto> getAll() {
        log.info("Fetching all Product Group Criteria");
        return repository.findAll().stream()
                .map(mapper::toDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public ProductGroupCriteriaDto getById(Integer id) {
        log.info("Fetching Product Group Criteria by ID: {}", id);
        return repository.findById(id)
                .map(mapper::toDto)
                .orElse(null); // Handle not found as needed
    }

    @Transactional
    public ProductGroupCriteriaDto update(Integer id, ProductGroupCriteriaDto dto) {
        log.info("Updating Product Group Criteria ID: {} with data: {}", id, dto);
        Product_group_criteria existingEntity = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Product Group Criteria not found")); // Handle not found

        existingEntity.setEnableMinQuantityCheck(dto.getEnableMinQuantityCheck());
        existingEntity.setEnableMinProductVarietyCheck(dto.getEnableMinProductVarietyCheck());
        existingEntity.setMinQuantity(dto.getMinQuantity());
        existingEntity.setMinProductVariety(dto.getMinProductVariety());

        existingEntity = repository.save(existingEntity);
        return mapper.toDto(existingEntity);
    }

    @Transactional
    public void delete(Integer id) {
        log.info("Deleting Product Group Criteria ID: {}", id);
        if (!repository.existsById(id)) {
            throw new RuntimeException("Product Group Criteria not found"); // Handle not found
        }
        repository.deleteById(id);
    }
}
