package pivotrics.bikash.myproduct.data.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pivotrics.bikash.myproduct.data.entity.Merchant_catalog_config;

public interface MerchantCatalogConfigRepository extends JpaRepository<Merchant_catalog_config, Integer> {
}
