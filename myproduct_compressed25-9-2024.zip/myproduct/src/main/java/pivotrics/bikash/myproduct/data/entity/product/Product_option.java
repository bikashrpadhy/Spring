package pivotrics.bikash.myproduct.data.entity.product;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import pivotrics.bikash.myproduct.converter.StringArrayConverter;

import java.io.Serial;
import java.io.Serializable;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "product_option")
public class Product_option implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @Id
//    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @Column(name = "id", nullable = false)
    private Integer id; // creating ids manually

    @Column(name = "name", unique = true)
    private String name;
    
    @Column(name = "tags")
    @Convert(converter = StringArrayConverter.class)
    private List<String> tags;

    @Column(name = "permitted_values")
    @Convert(converter = StringArrayConverter.class)
    private List<String> permittedValues;

    @Column(name = "merchant_account_number")
    private Integer merchantAccountNumber;


}

// Issues- can accept an entire string permitted values. should validate input to be a list of strings first.