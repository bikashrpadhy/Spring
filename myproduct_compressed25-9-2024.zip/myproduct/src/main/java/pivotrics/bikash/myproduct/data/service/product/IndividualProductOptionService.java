package pivotrics.bikash.myproduct.data.service.product;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import pivotrics.bikash.myproduct.api.dto.IndividualProductOptionDto;
import pivotrics.bikash.myproduct.api.mapper.product.IndividualProductOptionMapper;
import pivotrics.bikash.myproduct.data.entity.product.Individual_product_option;
//import pivotrics.bikash.myproduct.data.entity.product.Merchant_products;
import pivotrics.bikash.myproduct.data.entity.product.Merchant_products;
import pivotrics.bikash.myproduct.data.entity.product.Product_option;
import pivotrics.bikash.myproduct.data.repository.product.IndividualProductOptionRepository;
import pivotrics.bikash.myproduct.data.repository.product.MerchantProductRepository;
import pivotrics.bikash.myproduct.data.repository.product.ProductOptionRepository;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class IndividualProductOptionService {

    private final IndividualProductOptionRepository optionRepository;
    private final IndividualProductOptionMapper optionMapper;
    private final MerchantProductRepository productRepository;
    private final ProductOptionRepository productOptionRepository;


    public IndividualProductOptionDto createOption(IndividualProductOptionDto dto) {
        log.info("Creating IndividualProductOption with data: {}", dto);
        Individual_product_option entity = optionMapper.toEntity(dto);
        Individual_product_option savedEntity = optionRepository.save(entity);
        log.info("Successfully created IndividualProductOption with ID: {}", savedEntity.getId());
        return optionMapper.toDto(savedEntity);
    }

    public List<IndividualProductOptionDto> getAllOptions() {
        log.info("Fetching all IndividualProductOptions");
        List<IndividualProductOptionDto> options = optionRepository.findAll()
                .stream()
                .map(optionMapper::toDto)
                .collect(Collectors.toList());
        log.info("Fetched {} IndividualProductOptions", options.size());
        return options;
    }

    public IndividualProductOptionDto getOptionById(Integer id) {
        log.info("Fetching IndividualProductOption with ID: {}", id);
        return optionRepository.findById(id)
                .map(optionMapper::toDto)
                .orElseThrow(() -> {
                    log.error("IndividualProductOption with ID {} not found", id);
                    return new RuntimeException("Option not found");
                });
    }

    public IndividualProductOptionDto updateOption(Integer id, IndividualProductOptionDto dto) {
        log.info("Updating IndividualProductOption with ID: {}", id);
        Individual_product_option existingOption = optionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Option not found with ID: " + id));

        Individual_product_option updatedEntity = optionMapper.toEntity(dto);

        // Handle references (if applicable)
        if (dto.getMerchantProduct() != null) {
            Merchant_products merchantProduct= productRepository.findById(dto.getMerchantProduct())
                    .orElseThrow(() -> new RuntimeException("MerchantProduct not found with id " + dto.getMerchantProduct()));

            updatedEntity.setMerchantProduct(merchantProduct);
        }

        if(dto.getProductOption()!= null){
            Product_option productOption= productOptionRepository.findById(dto.getProductOption())
                    .orElseThrow(()-> new RuntimeException("Product option not found with id "+ dto.getProductOption()));
            updatedEntity.setProductOption(productOption);
        }

        Individual_product_option savedEntity = optionRepository.save(updatedEntity);
        log.info("Successfully updated IndividualProductOption with ID: {}", savedEntity.getId());
        return optionMapper.toDto(savedEntity);
    }

    public void deleteOption(Integer id) {
        log.info("Deleting IndividualProductOption with ID: {}", id);
        if (!optionRepository.existsById(id)) {
            log.error("IndividualProductOption with ID {} does not exist", id);
            throw new RuntimeException("Option not found");
        }
        optionRepository.deleteById(id);
        log.info("Successfully deleted IndividualProductOption with ID: {}", id);
    }
}
