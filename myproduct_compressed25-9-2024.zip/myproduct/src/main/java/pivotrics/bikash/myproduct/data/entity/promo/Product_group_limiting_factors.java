package pivotrics.bikash.myproduct.data.entity.promo;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serial;
import java.io.Serializable;
import java.math.BigDecimal;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "product_group_limiting_factors")
public class Product_group_limiting_factors implements Serializable {
    @Serial
    private static final long serialVersionUID =1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false, unique = true)
    private Integer id;

    @Column(name = "max_allowed_quantity_per_txn")
    private Short maxAllowedQuantityPerTxn;

    @Column(name = "max_discount_on_subtotal_per_txn", precision = 12, scale = 2)
    private BigDecimal maxDiscountOnSubtotalPerTxn;

    @Column(name = "max_quantity_per_customer")
    private Short maxQuantityPerCustomer;

    @Column(name = "cumulative_quantity_allowed")
    private Short cumulativeQuantityAllowed;

    @Column(name = "enable_further_discount_at_cart_level_when_available")
    private Boolean enableFurtherDiscountAtCartLevelWhenAvailable;

    @Column(name = "max_additional_discount_in_percentage_at_cart_level")
    private Float maxAdditionalDiscountInPercentageAtCartLevel;

    @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "id_merchant_product_group", unique = true)
    private Merchant_product_group merchantProductGroup;

}