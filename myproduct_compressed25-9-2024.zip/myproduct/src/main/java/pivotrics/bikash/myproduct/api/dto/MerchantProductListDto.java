package pivotrics.bikash.myproduct.api.dto;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.List;

@Getter
@Setter
public class MerchantProductListDto implements Serializable {
    private static final long serialVersionUID = 1L;

    private Integer id;
    private Boolean isEnabled;
    private ZonedDateTime createdOn;
    private ZonedDateTime lastUpdated;
    private String listDescription;
    private String listName;
    private Integer merchantAccountNumber;
//    private List<Integer> productList;
//    we'll do the json list later

    // getters and setters
}