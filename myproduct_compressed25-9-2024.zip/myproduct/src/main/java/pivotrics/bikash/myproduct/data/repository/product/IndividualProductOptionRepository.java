package pivotrics.bikash.myproduct.data.repository.product;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import pivotrics.bikash.myproduct.data.entity.product.Individual_product_option;

@Repository
public interface IndividualProductOptionRepository extends JpaRepository<Individual_product_option, Integer> {
}
