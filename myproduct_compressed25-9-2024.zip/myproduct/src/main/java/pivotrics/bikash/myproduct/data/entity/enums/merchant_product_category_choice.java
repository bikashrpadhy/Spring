package pivotrics.bikash.myproduct.data.entity.enums;

import lombok.Getter;

@Getter
public enum merchant_product_category_choice {

    GOOGLE_CATEGORIES("Google Categories"),
    SHOPIFY_CATEGORIES("Shopify Categories"),
    SHOPIFY_CATEGORIES_WITH_CUSTOM_TYPES("Shopify Categories with Custom Types"),
    GOOGLE_CATEGORIES_WITH_CUSTOM_TYPES("Google Categories with Custom Types"),
    CUSTOM_TYPES_ONLY("Custom Types Only");

    // Getter for the display name
    private final String displayName;

    // Private constructor to set the display name for each enum constant
    private merchant_product_category_choice(String displayName) {
        this.displayName = displayName;
    }

    // Static method to get the enum constant from a display name
    public static merchant_product_category_choice fromDisplayName(String displayName) {
        for (merchant_product_category_choice choice : merchant_product_category_choice.values()) {
            if (choice.getDisplayName().equalsIgnoreCase(displayName)) {
                return choice;
            }
        }
        throw new IllegalArgumentException("No enum constant with display name " + displayName);
    }

    @Override
    public String toString() {
        return displayName;
    }
}
