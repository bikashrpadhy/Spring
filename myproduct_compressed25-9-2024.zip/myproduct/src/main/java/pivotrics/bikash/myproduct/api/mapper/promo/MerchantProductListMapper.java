package pivotrics.bikash.myproduct.api.mapper.promo;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import pivotrics.bikash.myproduct.api.dto.MerchantProductListDto;
import pivotrics.bikash.myproduct.data.entity.promo.Merchant_product_list;

//@Mapper(componentModel = "spring", injectionStrategy = InjectionStrategy.CONSTRUCTOR)
@Mapper(componentModel = "spring")
public interface MerchantProductListMapper {

    // Generated instance of the mapper
    MerchantProductListMapper INSTANCE = Mappers.getMapper(MerchantProductListMapper.class);

    // Map entity to DTO
    MerchantProductListDto toDto(Merchant_product_list merchantProductList);

    // Map DTO to entity
    Merchant_product_list toEntity(MerchantProductListDto merchantProductListDto);
}
