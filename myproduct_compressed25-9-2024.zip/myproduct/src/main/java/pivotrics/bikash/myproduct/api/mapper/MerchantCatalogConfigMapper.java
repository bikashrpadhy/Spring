package pivotrics.bikash.myproduct.api.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;
import pivotrics.bikash.myproduct.api.dto.MerchantCatalogConfigDto;
import pivotrics.bikash.myproduct.data.entity.Merchant_catalog_config;

@Mapper(componentModel = "spring")
public interface MerchantCatalogConfigMapper {
    MerchantCatalogConfigMapper INSTANCE = Mappers.getMapper(MerchantCatalogConfigMapper.class);

    Merchant_catalog_config toEntity(MerchantCatalogConfigDto dto);

    MerchantCatalogConfigDto toDto(Merchant_catalog_config entity);
}
