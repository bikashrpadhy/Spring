package pivotrics.bikash.myproduct.data.service.product;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import pivotrics.bikash.myproduct.api.dto.MerchantProductDto;
import pivotrics.bikash.myproduct.api.mapper.product.MerchantProductMapper;
import pivotrics.bikash.myproduct.data.entity.category.Google_product_category;
import pivotrics.bikash.myproduct.data.entity.category.Merchant_product_type;
import pivotrics.bikash.myproduct.data.entity.category.Shopify_product_category;
import pivotrics.bikash.myproduct.data.entity.enums.MerchantProductClassification;
import pivotrics.bikash.myproduct.data.entity.product.Merchant_product_brand;
import pivotrics.bikash.myproduct.data.entity.product.Merchant_product_variation;
import pivotrics.bikash.myproduct.data.entity.product.Merchant_products;
import pivotrics.bikash.myproduct.data.entity.product.Merchant_tax_config;
import pivotrics.bikash.myproduct.data.repository.category.GoogleProductCategoryRepository;
import pivotrics.bikash.myproduct.data.repository.category.MerchantProductTypeRepository;
import pivotrics.bikash.myproduct.data.repository.category.ShopifyProductCategoryRepository;
import pivotrics.bikash.myproduct.data.repository.product.MerchantProductBrandRepository;
import pivotrics.bikash.myproduct.data.repository.product.MerchantProductRepository;
import pivotrics.bikash.myproduct.data.repository.product.MerchantTaxConfigRepository;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class MerchantProductService {
    private final MerchantProductRepository repository;
    private final MerchantProductMapper mapper;
    private final GoogleProductCategoryRepository googleRepository;
    private final MerchantProductBrandRepository mProductBrandRepo;
    private final MerchantProductTypeRepository mProductTypeRepo;
    private final MerchantTaxConfigRepository mTaxConfigRepo;
    private final ShopifyProductCategoryRepository ShopifyRepo;

    @Transactional
    public MerchantProductDto create(MerchantProductDto dto) {
        log.info("Creating Merchant Product: {}", dto);
        Merchant_products entity = mapper.toEntity(dto);
        entity = repository.save(entity);
        return mapper.toDto(entity);
    }

    @Transactional(readOnly = true)
    public List<MerchantProductDto> getAll() {
        log.info("Fetching all Merchant Products");
        return repository.findAll().stream()
                .map(mapper::toDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public MerchantProductDto getById(Integer id) {
        log.info("Fetching Merchant Product by ID: {}", id);
        return repository.findById(id)
                .map(mapper::toDto)
                .orElse(null); // Handle not found as needed
    }

    @Transactional
    public MerchantProductDto update(Integer id, MerchantProductDto dto) {
        log.info("Updating Merchant Product ID: {} with data: {}", id, dto);
        Merchant_products existingEntity = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Merchant Product not found")); // Handle not found

        existingEntity.setSku(dto.getSku());
        existingEntity.setTags(dto.getTags());
        existingEntity.setUpc(dto.getUpc());
        existingEntity.setProductName(dto.getProductName());

        existingEntity.setParentProductId(dto.getParentProductId());
        existingEntity.setMerchantAccountNumber(dto.getMerchantAccountNumber());
        existingEntity.setMerchantDepartmentId(dto.getMerchantDepartmentId());
        existingEntity.setMrp(dto.getMrp());
        existingEntity.setSellingPrice(dto.getSellingPrice());
        existingEntity.setLowestDiscountedPrice(dto.getLowestDiscountedPrice());
        existingEntity.setForceExclusionFromPromotion(dto.getForceExclusionFromPromotion());
        existingEntity.setTaxApplicable(dto.getTaxApplicable());
        existingEntity.setReturnable(dto.getReturnable());
        existingEntity.setShippingRequired(dto.getShippingRequired());
        existingEntity.setIsEnabled(dto.getIsEnabled());
        existingEntity.setCreatedOn(dto.getCreatedOn());
        existingEntity.setLastUpdated(dto.getLastUpdated());
        if(dto.getProductClass()!=null){
            existingEntity.setProductClass(Enum.valueOf(MerchantProductClassification.class, dto.getProductClass()));
        }

        if(dto.getGoogleProductCategory()!=null){
            Google_product_category googleProductCategory= googleRepository.findById(dto.getGoogleProductCategory())
                    .orElseThrow(()->new RuntimeException("Google Product Category not found with id " + dto.getGoogleProductCategory()));

            existingEntity.setGoogleProductCategory(googleProductCategory);
        }

        if(dto.getMerchantProductBrand()!=null){
            Merchant_product_brand merchantProductBrand= mProductBrandRepo.findById(dto.getMerchantProductBrand())
                    .orElseThrow(()->new RuntimeException("Merchant Product Brand not found with id " + dto.getMerchantProductBrand()));

            existingEntity.setMerchantProductBrand(merchantProductBrand);
        }

        if(dto.getMerchantProductType()!=null){
            Merchant_product_type merchantProductType= mProductTypeRepo.findById(dto.getMerchantProductType())
                    .orElseThrow(()->new RuntimeException("Merchant Product Type not found with id " + dto.getMerchantProductType()));

            existingEntity.setMerchantProductType(merchantProductType);
        }

        if(dto.getMerchantTaxConfig()!=null){
            Merchant_tax_config merchantTaxConfig= mTaxConfigRepo.findById(dto.getMerchantTaxConfig())
                    .orElseThrow(()->new RuntimeException("Merchant Product Tax Config not found with id " + dto.getMerchantTaxConfig()));

            existingEntity.setMerchantTaxConfig(merchantTaxConfig);
        }

        if(dto.getShopifyProductCategory()!=null){
            Shopify_product_category shopifyProductCategory= ShopifyRepo.findById(dto.getShopifyProductCategory())
                    .orElseThrow(()->new RuntimeException("Shopify Product Category not found with id " + dto.getShopifyProductCategory()));

            existingEntity.setShopifyProductCategory(shopifyProductCategory);
        }

        existingEntity = repository.save(existingEntity);
        return mapper.toDto(existingEntity);
    }

    @Transactional
    public void delete(Integer id) {
        log.info("Deleting Merchant Product ID: {}", id);
        if (!repository.existsById(id)) {
            throw new RuntimeException("Merchant Product not found"); // Handle not found
        }
//        Merchant_products entityToDelete= repository.findById(id)
//                        .orElseThrow(()->new RuntimeException("Merchant Product not found with id " + id));


//        Merchant_product_variation merchantProductVariation= entityToDelete.getMerchan
//        entityToDelete.setShopifyProductCategory(null);
//        entityToDelete.setGoogleProductCategory(null);
//        entityToDelete.setMerchantTaxConfig(null);
//        entityToDelete.setMerchantProductType(null);
//        entityToDelete.setMerchantProductBrand(null);
        repository.deleteById(id);
    }
}
