package pivotrics.bikash.myproduct.api.mapper.promo;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;
import pivotrics.bikash.myproduct.api.dto.ProductGroupCriteriaDto;
import pivotrics.bikash.myproduct.data.entity.promo.Product_group_criteria;

@Mapper(componentModel = "spring")
public interface ProductGroupCriteriaMapper {
    ProductGroupCriteriaMapper INSTANCE = Mappers.getMapper(ProductGroupCriteriaMapper.class);

    @Mapping(source = "merchantProductGroup", target = "merchantProductGroup.id")
    Product_group_criteria toEntity(ProductGroupCriteriaDto dto);

    @Mapping(target = "merchantProductGroup", source = "merchantProductGroup.id")
    ProductGroupCriteriaDto toDto(Product_group_criteria entity);
}
