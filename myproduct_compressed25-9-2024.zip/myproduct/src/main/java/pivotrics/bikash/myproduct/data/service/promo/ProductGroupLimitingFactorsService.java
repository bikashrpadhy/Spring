package pivotrics.bikash.myproduct.data.service.promo;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import pivotrics.bikash.myproduct.api.dto.ProductGroupLimitingFactorDto;
import pivotrics.bikash.myproduct.api.mapper.promo.ProductGroupLimitingFactorsMapper;
import pivotrics.bikash.myproduct.data.entity.promo.Product_group_limiting_factors;
import pivotrics.bikash.myproduct.data.repository.promo.ProductGroupLimitingFactorsRepository;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class ProductGroupLimitingFactorsService {
    private final ProductGroupLimitingFactorsRepository repository;
    private final ProductGroupLimitingFactorsMapper mapper;

    @Transactional
    public ProductGroupLimitingFactorDto create(ProductGroupLimitingFactorDto dto) {
        log.info("Creating Product Group Limiting Factors: {}", dto);
        Product_group_limiting_factors entity = mapper.toEntity(dto);
        entity = repository.save(entity);
        return mapper.toDto(entity);
    }

    @Transactional(readOnly = true)
    public List<ProductGroupLimitingFactorDto> getAll() {
        log.info("Fetching all Product Group Limiting Factors");
        return repository.findAll().stream()
                .map(mapper::toDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public ProductGroupLimitingFactorDto getById(Integer id) {
        log.info("Fetching Product Group Limiting Factors by ID: {}", id);
        return repository.findById(id)
                .map(mapper::toDto)
                .orElse(null); // Handle not found as needed
    }

    @Transactional
    public ProductGroupLimitingFactorDto update(Integer id, ProductGroupLimitingFactorDto dto) {
        log.info("Updating Product Group Limiting Factors ID: {} with data: {}", id, dto);
        Product_group_limiting_factors existingEntity = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Product Group Limiting Factors not found")); // Handle not found

        existingEntity.setMaxAllowedQuantityPerTxn(dto.getMaxAllowedQuantityPerTxn());
        existingEntity.setMaxDiscountOnSubtotalPerTxn(dto.getMaxDiscountOnSubtotalPerTxn());
        existingEntity.setMaxQuantityPerCustomer(dto.getMaxQuantityPerCustomer());
        existingEntity.setCumulativeQuantityAllowed(dto.getCumulativeQuantityAllowed());
        existingEntity.setEnableFurtherDiscountAtCartLevelWhenAvailable(dto.getEnableFurtherDiscountAtCartLevelWhenAvailable());
        existingEntity.setMaxAdditionalDiscountInPercentageAtCartLevel(dto.getMaxAdditionalDiscountInPercentageAtCartLevel());

        existingEntity = repository.save(existingEntity);
        return mapper.toDto(existingEntity);
    }

    @Transactional
    public void delete(Integer id) {
        log.info("Deleting Product Group Limiting Factors ID: {}", id);
        if (!repository.existsById(id)) {
            throw new RuntimeException("Product Group Limiting Factors not found"); // Handle not found
        }
        repository.deleteById(id);
    }
}
