package pivotrics.bikash.myproduct.data.entity.enums;

import lombok.Getter;

@Getter
public enum MerchantProductClassification {

        SIMPLE_PRODUCT("Simple Product"),
        COMPLEX_PRODUCT("Complex Product"),
        VARIATION("Variation");

        private final String displayName;

        MerchantProductClassification(String displayName) {
            this.displayName = displayName;
        }

    public static MerchantProductClassification fromDisplayName(String displayName) {
            for (MerchantProductClassification classification : MerchantProductClassification.values()) {
                if (classification.getDisplayName().equalsIgnoreCase(displayName)) {
                    return classification;
                }
            }
            throw new IllegalArgumentException("No enum constant with display name " + displayName);
        }
    }


