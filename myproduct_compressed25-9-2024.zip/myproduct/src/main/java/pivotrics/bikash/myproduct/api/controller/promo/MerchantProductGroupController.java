package pivotrics.bikash.myproduct.api.controller.promo;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pivotrics.bikash.myproduct.api.dto.MerchantProductGroupDto;
import pivotrics.bikash.myproduct.data.service.promo.MerchantProductGroupService;

import java.util.List;

@RestController
@RequestMapping("/merchant-product-groups")
@RequiredArgsConstructor
public class MerchantProductGroupController {

    private final MerchantProductGroupService service;

    @GetMapping
    public ResponseEntity<List<MerchantProductGroupDto>> getAll() {
        return ResponseEntity.ok(service.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<MerchantProductGroupDto> getById(@PathVariable Integer id) {
        MerchantProductGroupDto dto = service.findById(id);
        return dto != null ? ResponseEntity.ok(dto) : ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<MerchantProductGroupDto> create(@RequestBody MerchantProductGroupDto dto) {
        return ResponseEntity.ok(service.save(dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Integer id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
