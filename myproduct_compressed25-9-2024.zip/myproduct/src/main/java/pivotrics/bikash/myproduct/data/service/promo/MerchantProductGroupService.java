package pivotrics.bikash.myproduct.data.service.promo;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import pivotrics.bikash.myproduct.api.dto.MerchantProductGroupDto;
import pivotrics.bikash.myproduct.api.mapper.product.MerchantProductGroupMapper;
import pivotrics.bikash.myproduct.data.entity.promo.Merchant_product_group;
import pivotrics.bikash.myproduct.data.repository.promo.MerchantProductGroupRepository;

//import pivotrics.bikash.myproduct.api.entity.MerchantProductGroup;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class MerchantProductGroupService {

    private final MerchantProductGroupRepository repository;
    private final MerchantProductGroupMapper mapper;

    @Transactional(readOnly = true)
    public List<MerchantProductGroupDto> findAll() {
        log.info("Fetching all Merchant Product Groups");
        return mapper.toDtoList(repository.findAll());
    }

    @Transactional(readOnly = true)
    public MerchantProductGroupDto findById(Integer id) {
        log.info("Fetching Merchant Product Group with ID: {}", id);
        return mapper.toDto(repository.findById(id).orElse(null));
    }

    @Transactional
    public MerchantProductGroupDto save(MerchantProductGroupDto dto) {
        log.info("Saving Merchant Product Group: {}", dto);
        Merchant_product_group entity = mapper.toEntity(dto);
        Merchant_product_group savedEntity = repository.save(entity);
        return mapper.toDto(savedEntity);
    }

    @Transactional
    public MerchantProductGroupDto update(Integer id, MerchantProductGroupDto dto) {
        log.info("Updating Merchant Product Group with ID: {}", id);
        if (!repository.existsById(id)) {
            log.warn("Merchant Product Group with ID: {} not found", id);
            return null; // Handle not found scenario as needed
        }
        dto.setId(id); // Ensure the ID is set for the update
        Merchant_product_group entity = mapper.toEntity(dto);
        Merchant_product_group updatedEntity = repository.save(entity);
        return mapper.toDto(updatedEntity);
    }

    @Transactional
    public void delete(Integer id) {
        log.info("Deleting Merchant Product Group with ID: {}", id);
        repository.deleteById(id);
    }
}
