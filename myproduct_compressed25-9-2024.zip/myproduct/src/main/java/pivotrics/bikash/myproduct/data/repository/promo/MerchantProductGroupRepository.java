package pivotrics.bikash.myproduct.data.repository.promo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import pivotrics.bikash.myproduct.data.entity.promo.Merchant_product_group;

@Repository
public interface MerchantProductGroupRepository extends JpaRepository<Merchant_product_group, Integer> {
}
