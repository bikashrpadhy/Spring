package pivotrics.bikash.myproduct.data.entity.promo;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.io.Serial;
import java.io.Serializable;
import java.time.ZonedDateTime;

@Getter
@Setter
@Entity
@Table(name = "merchant_product_restriction")
public class Merchant_product_restriction implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

//     list of json
//    restricted_product_list;

    @Column(name = "restrictionName")
    private String restrictionName;

    @Column(name = "restrictionDescription")
    private String restrictionDescription;

    @Column(name = "lastUpdated")
    private ZonedDateTime lastUpdated;

    @Column(name = "isEnabled")
    private Boolean isEnabled;

    @Column(name = "merchant_account_number")
    private Integer merchantAccountNumber;

}