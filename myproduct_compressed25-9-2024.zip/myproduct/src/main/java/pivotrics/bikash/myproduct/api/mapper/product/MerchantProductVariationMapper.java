package pivotrics.bikash.myproduct.api.mapper.product;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;
import pivotrics.bikash.myproduct.api.dto.MerchantProductVariationDto;
import pivotrics.bikash.myproduct.data.entity.product.Merchant_product_variation;

@Mapper(componentModel = "spring")
public interface MerchantProductVariationMapper {

    MerchantProductVariationMapper INSTANCE = Mappers.getMapper(MerchantProductVariationMapper.class);

    @Mapping(source = "merchantProduct.id", target = "merchantProduct") // Map the entity reference back to ID
    MerchantProductVariationDto toDto(Merchant_product_variation merchantProductVariation);

    @Mapping(source = "merchantProduct", target = "merchantProduct.id") // Map the ID to the entity reference
    Merchant_product_variation toEntity(MerchantProductVariationDto merchantProductVariationDto);
}
