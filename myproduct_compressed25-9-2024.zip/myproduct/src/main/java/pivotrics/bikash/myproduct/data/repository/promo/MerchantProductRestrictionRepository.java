package pivotrics.bikash.myproduct.data.repository.promo;

import org.springframework.data.jpa.repository.JpaRepository;
import pivotrics.bikash.myproduct.data.entity.promo.Merchant_product_restriction;

public interface MerchantProductRestrictionRepository extends JpaRepository<Merchant_product_restriction, Integer> {
    // Custom query methods can be added here if needed
}
