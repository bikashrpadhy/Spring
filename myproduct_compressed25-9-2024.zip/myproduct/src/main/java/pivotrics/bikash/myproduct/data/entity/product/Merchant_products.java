package pivotrics.bikash.myproduct.data.entity.product;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import pivotrics.bikash.myproduct.converter.IntegerListConverter;
import pivotrics.bikash.myproduct.converter.StringArrayConverter;
import pivotrics.bikash.myproduct.data.entity.category.Google_product_category;
import pivotrics.bikash.myproduct.data.entity.category.Merchant_product_type;
import pivotrics.bikash.myproduct.data.entity.category.Shopify_product_category;
import pivotrics.bikash.myproduct.data.entity.enums.MerchantProductClassification;

import java.io.Serial;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.List;


@Getter
@Setter
//@NoArgsConstructor
//@AllArgsConstructor
@Entity
@Table(name = "merchant_products")
public class Merchant_products implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @Column(name = "sku")
    private String sku;

    @Column(name = "productName", nullable = false)
    private String productName;

    @Column(name = "tags")
    @Convert(converter = StringArrayConverter.class)
    private List<String> tags;

    @Column(name = "merchantAccountNumber", nullable = false)
    private Integer merchantAccountNumber;

    @Column(name = "merchantDepartmentId", nullable = false)
    @Convert(converter = IntegerListConverter.class)
    private List<Integer> merchantDepartmentId;

    @Column(name = "mrp", precision = 19, scale = 2)
    private BigDecimal mrp;

    @Column(name = "upc", nullable = false)
    private String upc;

    @Enumerated(EnumType.STRING)
    @Column(name = "productClass", nullable = false)
    private MerchantProductClassification productClass;

    @Column(name = "parentProductId")
    private Integer parentProductId;

    @Column(name = "sellingPrice", precision = 19, scale = 2)
    private BigDecimal sellingPrice;

    @Column(name = "lowestDiscountedPrice", precision = 19, scale = 2)
    private BigDecimal lowestDiscountedPrice;

    @Column(name = "forceExclusionFromPromotion")
    private Boolean forceExclusionFromPromotion;

    @Column(name = "taxApplicable")
    private Boolean taxApplicable;

    @Column(name = "returnable")
    private Boolean returnable;

    @Column(name = "isEnabled")
    private Boolean isEnabled;

    @Column(name = "shippingRequired")
    private Boolean shippingRequired;

    @Column(name = "createdOn")
    private ZonedDateTime createdOn;

    @Column(name = "lastUpdated")
    private ZonedDateTime lastUpdated;



    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "id_merchantTaxConfig", nullable = false)
    private Merchant_tax_config merchantTaxConfig;

    @ManyToOne(cascade = CascadeType.DETACH)
    @JoinColumn(name = "id_merchant_product_brand")
    private Merchant_product_brand merchantProductBrand;

    @ManyToOne(cascade = CascadeType.DETACH)
    @JoinColumn(name = "id_merchant_product_type")
    private Merchant_product_type merchantProductType;

    @ManyToOne(cascade = CascadeType.DETACH)
    @JoinColumn(name = "id_googleProductCategory")
    private Google_product_category googleProductCategory;

    @ManyToOne(cascade = CascadeType.DETACH)
    @JoinColumn(name = "id_shopifyProductCategory")
    private Shopify_product_category shopifyProductCategory;

}
