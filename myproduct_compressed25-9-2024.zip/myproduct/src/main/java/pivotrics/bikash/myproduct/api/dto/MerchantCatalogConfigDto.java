package pivotrics.bikash.myproduct.api.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import pivotrics.bikash.myproduct.data.entity.enums.merchant_product_category_choice;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class MerchantCatalogConfigDto {
    private Integer id;
    private Integer merchantAccountNumber;
    private Short maxAllowedProduct;
    private Short maxAllowedType;
    private String categoriesChoice;
    private Short maxAllowedProductLists;
    private Short maxAllowedEnabledProductLists;
    private Short maxAllowedProductsInProductList;
    private Short maxAllowedProductGroup;
    private Short maxAllowedEnabledProductGroups;
    private Short maxCategoriesInProductGroup;
    private Short maxProductTypesInProductGroup;
    private Short maxProductsInComboProductGroup;
    private Short maxIndividualProductsInProductGroup;
}
