package pivotrics.bikash.myproduct.api.mapper.product;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import pivotrics.bikash.myproduct.api.dto.MerchantProductGroupDto;
import pivotrics.bikash.myproduct.data.entity.promo.Merchant_product_group;

import java.util.List;

@Mapper
public interface MerchantProductGroupMapper {

    MerchantProductGroupMapper INSTANCE = Mappers.getMapper(MerchantProductGroupMapper.class);

    MerchantProductGroupDto toDto(Merchant_product_group entity);
    Merchant_product_group toEntity(MerchantProductGroupDto dto);
    List<MerchantProductGroupDto> toDtoList(List<Merchant_product_group> entities);
    List<Merchant_product_group> toEntityList(List<MerchantProductGroupDto> dtos);
}
