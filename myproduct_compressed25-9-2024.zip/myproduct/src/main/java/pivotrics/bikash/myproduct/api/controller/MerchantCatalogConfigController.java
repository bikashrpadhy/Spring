// working
package pivotrics.bikash.myproduct.api.controller;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pivotrics.bikash.myproduct.api.dto.MerchantCatalogConfigDto;
import pivotrics.bikash.myproduct.data.service.MerchantCatalogConfigService;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/merchant-catalog-config")
@RequiredArgsConstructor
public class MerchantCatalogConfigController {
    private final MerchantCatalogConfigService service;

    @PostMapping
    public ResponseEntity<MerchantCatalogConfigDto> create(@RequestBody MerchantCatalogConfigDto dto) {
        log.info("Creating Merchant Catalog Config: {}", dto);
        MerchantCatalogConfigDto createdDto = service.create(dto);
        return new ResponseEntity<>(createdDto, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<MerchantCatalogConfigDto>> getAll() {
        log.info("Fetching all Merchant Catalog Configs");
        List<MerchantCatalogConfigDto> dtos = service.getAll();
        return new ResponseEntity<>(dtos, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<MerchantCatalogConfigDto> getById(@PathVariable Integer id) {
        log.info("Fetching Merchant Catalog Config by ID: {}", id);
        MerchantCatalogConfigDto dto = service.getById(id);
        return dto != null ? new ResponseEntity<>(dto, HttpStatus.OK) : ResponseEntity.notFound().build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<MerchantCatalogConfigDto> update(@PathVariable Integer id, @RequestBody MerchantCatalogConfigDto dto) {
        log.info("Updating Merchant Catalog Config ID: {} with data: {}", id, dto);
        MerchantCatalogConfigDto updatedDto = service.update(id, dto);
        return new ResponseEntity<>(updatedDto, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Integer id) {
        log.info("Deleting Merchant Catalog Config ID: {}", id);
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
