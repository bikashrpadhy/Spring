package pivotrics.bikash.myproduct.api.mapper.product;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;
import pivotrics.bikash.myproduct.api.dto.MerchantProductDto;
import pivotrics.bikash.myproduct.data.entity.product.Merchant_products;

@Mapper(componentModel = "spring")
public interface MerchantProductMapper {
    MerchantProductMapper INSTANCE = Mappers.getMapper(MerchantProductMapper.class);

    @Mapping(source = "googleProductCategory", target = "googleProductCategory.id")
    @Mapping(source = "merchantProductBrand", target = "merchantProductBrand.id")
    @Mapping(source = "merchantProductType", target = "merchantProductType.id")
    @Mapping(source = "merchantTaxConfig", target = "merchantTaxConfig.id")
    @Mapping(source = "shopifyProductCategory", target = "shopifyProductCategory.id")
    Merchant_products toEntity(MerchantProductDto dto);

    @Mapping(target = "googleProductCategory", source = "googleProductCategory.id")
    @Mapping(target = "merchantProductBrand", source = "merchantProductBrand.id")
    @Mapping(target = "merchantProductType", source = "merchantProductType.id")
    @Mapping(target = "merchantTaxConfig", source = "merchantTaxConfig.id")
    @Mapping(target = "shopifyProductCategory", source = "shopifyProductCategory.id")
    MerchantProductDto toDto(Merchant_products entity);
}
