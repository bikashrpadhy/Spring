package pivotrics.bikash.myproduct.api.dto;



import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.List;

@Getter
@Setter
public class MerchantProductGroupDto implements Serializable {
    private Integer id;
    private String groupDescription;
    private String groupName;
    private String productGroupType;
    private Boolean isEnabled;
    private Boolean isActive;
    private Boolean isDeleted;
    private Integer merchantAccountNumber;
    private List<Integer> individualProductIds;
    private List<Integer> productComboIds;
    private ZonedDateTime createdOn;
    private ZonedDateTime lastUpdated;

    private List<Integer> googleProductCategories;
    private List<Integer> shopifyProductCategories;
    private List<Integer> merchantProductTypes;
    private Integer merchantProductBrand;
    private Integer merchantProductList;
    private Integer productGroupCriteria;
    private Integer productGroupLimitingFactors;
}