package pivotrics.bikash.myproduct.data.entity.promo;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serial;
import java.io.Serializable;
import java.time.OffsetDateTime;
import java.time.ZonedDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "merchant_product_list")
public class Merchant_product_list implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    //product list is a json[] ??


    @Column(name = "listName")
    private String listName;

    @Column(name = "listDescription")
    private String listDescription;

    @Column(name = "lastUpdated")
    private ZonedDateTime lastUpdated;

    @Column(name = "createdOn")
    private ZonedDateTime createdOn;

    @Column(name = "isEnabled")
    private Boolean isEnabled;

    @Column(name = "merchantAccountNumber")
    private Integer merchantAccountNumber;
}