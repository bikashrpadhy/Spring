package pivotrics.bikash.myproduct.api.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class MerchantProductVariationDto implements Serializable {
    private Integer id;
    private String variationName;
    private Integer merchantAccountNumber;
    private Integer merchantProduct;


//    private List<ProductOptionDto> productOptionDtos;
//    private MerchantProductDto merchantProductDto;
}