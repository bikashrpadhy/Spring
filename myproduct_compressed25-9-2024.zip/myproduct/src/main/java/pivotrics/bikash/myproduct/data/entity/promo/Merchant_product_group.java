package pivotrics.bikash.myproduct.data.entity.promo;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import pivotrics.bikash.myproduct.converter.IntegerListConverter;
import pivotrics.bikash.myproduct.converter.StringArrayConverter;
import pivotrics.bikash.myproduct.data.entity.category.Google_product_category;
import pivotrics.bikash.myproduct.data.entity.category.Merchant_product_type;
import pivotrics.bikash.myproduct.data.entity.category.Shopify_product_category;
import pivotrics.bikash.myproduct.data.entity.product.Merchant_product_brand;
import pivotrics.bikash.myproduct.data.entity.enums.product_group_type;

import java.io.Serial;
import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "merchant_product_group")
public class Merchant_product_group implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @Column(name = "group_name")
    private String groupName;

    @Column(name = "group_description")
    private String groupDescription;

    @Column(name = "merchant_account_number")
    private Integer merchantAccountNumber;

    @Enumerated(EnumType.STRING)
    @Column(name = "product_group_type")
    private product_group_type productGroupType;

    @Column(name = "individual_product_id")
    @Convert(converter = IntegerListConverter.class)
    private List<Integer> individualProductIds;

    @Column(name = "product_combo_ids")
    @Convert(converter = IntegerListConverter.class)
    private List<Integer> productComboIds;

    @Column(name = "last_updated")
    private OffsetDateTime lastUpdated;

    @Column(name = "created_on")
    private OffsetDateTime createdOn;

    @Column(name = "is_enabled")
    private Boolean isEnabled;

    @Column(name = "is_active")
    private Boolean isActive;

    @Column(name = "is_deleted")
    private Boolean isDeleted;

    @OneToOne(mappedBy = "merchant_product_group", orphanRemoval = true)
    private Product_group_criteria productGroupCriteria; // bidirectional

    @OneToOne(orphanRemoval = true, cascade = CascadeType.ALL)
    @JoinColumn(name = "product_group_limiting_factors_id")
    private Product_group_limiting_factors productGroupLimitingFactors; // bidirectional

    @ManyToOne(cascade = {CascadeType.ALL})
    private Merchant_product_brand merchantProductBrand; // unidirectional

    @ManyToOne
    @JoinColumn(name = "id_merchant_product_list")
    private Merchant_product_list merchantProductList; // unidirectional

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "many_merchant_product_group_has_many_merchant_product_types",
            joinColumns = @JoinColumn(name = "merchant_product_group_id"),
            inverseJoinColumns = @JoinColumn(name = "merchant_product_types_id"))
    private List<Merchant_product_type> merchantProductTypes;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "many_merchant_product_group_has_many_shopify_product_categories",
            joinColumns = @JoinColumn(name = "merchant_product_group_id"),
            inverseJoinColumns = @JoinColumn(name = "shopify_product_categories_id"))
    private List<Shopify_product_category> shopifyProductCategories;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "many_merchant_product_group_has_many_google_product_categories",
            joinColumns = @JoinColumn(name = "merchant_product_group_id"),
            inverseJoinColumns = @JoinColumn(name = "google_product_categories_id"))
    private List<Google_product_category> googleProductCategories;

}