// working
package pivotrics.bikash.myproduct.api.controller.promo;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pivotrics.bikash.myproduct.api.dto.ProductGroupLimitingFactorDto;
import pivotrics.bikash.myproduct.data.service.promo.ProductGroupLimitingFactorsService;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/product-group-limiting-factors")
@RequiredArgsConstructor
public class ProductGroupLimitingFactorsController {
    private final ProductGroupLimitingFactorsService service;

    @PostMapping
    public ResponseEntity<ProductGroupLimitingFactorDto> create(@RequestBody ProductGroupLimitingFactorDto dto) {
        log.info("Creating Product Group Limiting Factors: {}", dto);
        ProductGroupLimitingFactorDto createdDto = service.create(dto);
        return new ResponseEntity<>(createdDto, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<ProductGroupLimitingFactorDto>> getAll() {
        log.info("Fetching all Product Group Limiting Factors");
        List<ProductGroupLimitingFactorDto> dtos = service.getAll();
        return new ResponseEntity<>(dtos, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ProductGroupLimitingFactorDto> getById(@PathVariable Integer id) {
        log.info("Fetching Product Group Limiting Factors by ID: {}", id);
        ProductGroupLimitingFactorDto dto = service.getById(id);
        return dto != null ? new ResponseEntity<>(dto, HttpStatus.OK) : ResponseEntity.notFound().build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<ProductGroupLimitingFactorDto> update(@PathVariable Integer id, @RequestBody ProductGroupLimitingFactorDto dto) {
        log.info("Updating Product Group Limiting Factors ID: {} with data: {}", id, dto);
        ProductGroupLimitingFactorDto updatedDto = service.update(id, dto);
        return new ResponseEntity<>(updatedDto, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Integer id) {
        log.info("Deleting Product Group Limiting Factors ID: {}", id);
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
