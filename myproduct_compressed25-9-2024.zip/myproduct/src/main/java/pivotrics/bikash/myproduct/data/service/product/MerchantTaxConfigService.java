package pivotrics.bikash.myproduct.data.service.product;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import pivotrics.bikash.myproduct.api.dto.MerchantTaxConfigDto;
import pivotrics.bikash.myproduct.data.entity.product.Merchant_tax_config;
import pivotrics.bikash.myproduct.data.repository.product.MerchantTaxConfigRepository;


import java.util.List;
import java.util.stream.Collectors;

@Service
public class MerchantTaxConfigService {

    private static final Logger logger = LoggerFactory.getLogger(MerchantTaxConfigService.class);

    @Autowired
    private MerchantTaxConfigRepository repository;

    @Autowired
    private ModelMapper modelMapper; // Inject ModelMapper bean

    @Transactional
    public MerchantTaxConfigDto saveMerchantTaxConfig(MerchantTaxConfigDto merchantTaxConfigDto) {
        logger.info("Saving merchant tax config: {}", merchantTaxConfigDto);
        Merchant_tax_config entity = modelMapper.map(merchantTaxConfigDto, Merchant_tax_config.class);
        Merchant_tax_config savedEntity = repository.save(entity);
        return modelMapper.map(savedEntity, MerchantTaxConfigDto.class);
    }

    public List<MerchantTaxConfigDto> getAllMerchantTaxConfigs() {
        logger.info("Fetching all merchant tax configs");
        return repository.findAll().stream()
                .map(entity -> modelMapper.map(entity, MerchantTaxConfigDto.class))
                .collect(Collectors.toList());
    }

    public MerchantTaxConfigDto getMerchantTaxConfigById(Integer id) {
        logger.info("Fetching merchant tax config with id: {}", id);
        Merchant_tax_config entity = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("MerchantTaxConfig not found with id " + id));
        return modelMapper.map(entity, MerchantTaxConfigDto.class);
    }

    @Transactional
    public void deleteMerchantTaxConfig(Integer id) {
        try {
            logger.info("Deleting merchant tax config with id: {}", id);
            repository.deleteById(id);
        } catch (EmptyResultDataAccessException e) {
            logger.error("Failed to delete merchant tax config with id: {}. It does not exist.", id);
            throw new RuntimeException("MerchantTaxConfig not found with id " + id);
        }
    }

    @Transactional
    public MerchantTaxConfigDto updateMerchantTaxConfig(Integer id, MerchantTaxConfigDto updatedMerchantTaxConfigDto) {
        logger.info("Updating merchant tax config with id: {}", id);
        if (repository.existsById(id)) {
            Merchant_tax_config updatedEntity = modelMapper.map(updatedMerchantTaxConfigDto, Merchant_tax_config.class);
            updatedEntity.setId(id);
            Merchant_tax_config savedEntity = repository.save(updatedEntity);
            return modelMapper.map(savedEntity, MerchantTaxConfigDto.class);
        } else {
            throw new RuntimeException("MerchantTaxConfig not found with id " + id);
        }
    }
}
