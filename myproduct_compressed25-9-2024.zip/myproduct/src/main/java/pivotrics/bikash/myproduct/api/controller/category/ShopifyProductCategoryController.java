// working
package pivotrics.bikash.myproduct.api.controller.category;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import pivotrics.bikash.myproduct.api.dto.ShopifyProductCategoryDto;
import pivotrics.bikash.myproduct.data.service.category.ShopifyProductCategoryService;

import java.util.List;

@RestController
@RequestMapping("/shopify-product-categories")
public class ShopifyProductCategoryController {

    private static final Logger logger = LoggerFactory.getLogger(ShopifyProductCategoryController.class);

    @Autowired
    private ShopifyProductCategoryService service;

    @Autowired
    private ModelMapper modelMapper;

    @PostMapping
    public ResponseEntity<ShopifyProductCategoryDto> createCategory(@RequestBody ShopifyProductCategoryDto dto) {
        logger.info("Received request to create Shopify Product Category: {}", dto);
        ShopifyProductCategoryDto createdDto = service.createCategory(dto);
        return new ResponseEntity<>(createdDto, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<ShopifyProductCategoryDto>> getAllCategories() {
        logger.info("Received request to fetch all Shopify Product Categories");
        List<ShopifyProductCategoryDto> categories = service.getAllCategories();
        return new ResponseEntity<>(categories, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ShopifyProductCategoryDto> getCategoryById(@PathVariable Integer id) {
        logger.info("Received request to fetch Shopify Product Category with id: {}", id);
        ShopifyProductCategoryDto dto = service.getCategoryById(id);
        return new ResponseEntity<>(dto, HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ShopifyProductCategoryDto> updateCategory(@PathVariable Integer id, @RequestBody ShopifyProductCategoryDto dto) {
        logger.info("Received request to update Shopify Product Category with id: {}", id);
        ShopifyProductCategoryDto updatedDto = service.updateCategory(id, dto);
        return new ResponseEntity<>(updatedDto, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCategory(@PathVariable Integer id) {
        logger.info("Received request to delete Shopify Product Category with id: {}", id);
        service.deleteCategory(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
