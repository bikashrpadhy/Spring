package pivotrics.bikash.myproduct.converter;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Converter(autoApply = true)
public class IntegerListConverter implements AttributeConverter<List<Integer>, String> {

    @Override
    public String convertToDatabaseColumn(List<Integer> attribute) {
        if (attribute == null) {
            return null; // Handle null case
        }
        return attribute.stream()
                .map(String::valueOf)
                .collect(Collectors.joining(",")); // Convert List<Integer> to comma-separated String
    }

    @Override
    public List<Integer> convertToEntityAttribute(String dbData) {
        if (dbData == null || dbData.isEmpty()) {
            return List.of(); // Handle empty case
        }
        return Arrays.stream(dbData.split(","))
                .map(Integer::valueOf)
                .collect(Collectors.toList()); // Convert String back to List<Integer>
    }
}
