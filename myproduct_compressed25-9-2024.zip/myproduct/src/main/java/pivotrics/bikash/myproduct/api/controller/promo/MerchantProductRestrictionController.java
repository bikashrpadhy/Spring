// working
package pivotrics.bikash.myproduct.api.controller.promo;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pivotrics.bikash.myproduct.api.dto.MerchantProductRestrictionDto;
import pivotrics.bikash.myproduct.data.service.promo.MerchantProductRestrictionService;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/merchant-product-restrictions")
@RequiredArgsConstructor
public class MerchantProductRestrictionController {
    private final MerchantProductRestrictionService service;

    @PostMapping
    public ResponseEntity<MerchantProductRestrictionDto> create(@RequestBody MerchantProductRestrictionDto dto) {
        log.info("Creating Merchant Product Restriction: {}", dto);
        MerchantProductRestrictionDto createdDto = service.create(dto);
        return new ResponseEntity<>(createdDto, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<MerchantProductRestrictionDto>> getAll() {
        log.info("Fetching all Merchant Product Restrictions");
        List<MerchantProductRestrictionDto> dtos = service.getAll();
        return new ResponseEntity<>(dtos, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<MerchantProductRestrictionDto> getById(@PathVariable Integer id) {
        log.info("Fetching Merchant Product Restriction by ID: {}", id);
        MerchantProductRestrictionDto dto = service.getById(id);
        return dto != null ? new ResponseEntity<>(dto, HttpStatus.OK) : ResponseEntity.notFound().build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<MerchantProductRestrictionDto> update(@PathVariable Integer id, @RequestBody MerchantProductRestrictionDto dto) {
        log.info("Updating Merchant Product Restriction ID: {} with data: {}", id, dto);
        MerchantProductRestrictionDto updatedDto = service.update(id, dto);
        return new ResponseEntity<>(updatedDto, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Integer id) {
        log.info("Deleting Merchant Product Restriction ID: {}", id);
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
