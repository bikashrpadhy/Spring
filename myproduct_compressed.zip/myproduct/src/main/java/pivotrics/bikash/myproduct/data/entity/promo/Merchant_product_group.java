package pivotrics.bikash.myproduct.data.entity.promo;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import pivotrics.bikash.myproduct.data.entity.product.Merchant_product_brand;
import pivotrics.bikash.myproduct.data.entity.enums.product_group_type;

import java.io.Serial;
import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "merchant_product_group")
public class Merchant_product_group implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @Column(name = "group_name")
    private String group_name;

    @Column(name = "group_description")
    private String group_description;

    @Column(name = "merchant_account_number")
    private Integer merchant_account_number;

    @Enumerated(EnumType.STRING)
    @Column(name = "product_group_type")
    private product_group_type product_group_type;

    @ElementCollection
    @Column(name = "individual_product_id")
    @CollectionTable(name = "merchant_product_group_individual_product_ids", joinColumns = @JoinColumn(name = "id"))
    private List<Integer> individual_product_ids = new ArrayList<>();

    @ElementCollection
    @Column(name = "product_combo_id")
    @CollectionTable(name = "merchant_product_group_product_combo_ids", joinColumns = @JoinColumn(name = "id"))
    private List<Integer> product_combo_ids = new ArrayList<>();

    @Column(name = "last_updated")
    private OffsetDateTime last_updated;

    @Column(name = "created_on")
    private OffsetDateTime created_on;

    @Column(name = "is_enabled")
    private Boolean is_enabled;

    @Column(name = "is_active")
    private Boolean is_active;

    @Column(name = "is_deleted")
    private Boolean is_deleted;

    @ManyToOne(cascade = {CascadeType.ALL})
    private Merchant_product_brand merchant_product_brand;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_merchant_product_list")
    private Merchant_product_list merchant_product_list;



}