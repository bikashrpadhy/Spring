// working
package pivotrics.bikash.myproduct.data.entity.product;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serial;
import java.io.Serializable;
import java.time.OffsetDateTime;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "merchant_product_brand")
public class Merchant_product_brand implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @Column(name = "brandName", nullable = false, unique = true)
    private String brandName;

    @Column(name = "description")
    private String description;

    @Column(name = "brandCollaborationFlag")
    private Boolean brandCollaborationFlag;

    @Column(name = "createdOn")
    private ZonedDateTime createdOn;

    @Column(name = "lastUpdated")
    private ZonedDateTime lastUpdated;

    @Column(name = "isEnabled")
    private Boolean isEnabled;

    @Column(name = "merchantAccountNumber")
    private Integer merchantAccountNumber;

//    @OneToMany(mappedBy = "id_merchant_product_brand", cascade = CascadeType.ALL, orphanRemoval = true)
//    @OrderBy("product_name")
//    private List<Merchant_products> merchantProducts = new ArrayList<>();


}