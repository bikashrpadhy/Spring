package pivotrics.bikash.myproduct.api.dto;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

@Getter
@Setter
public class ProductOptionDto implements Serializable {
    private static final long serialVersionUID = 1L;

    private Integer id;
    private String name;
    private List<String> permittedValues;
    private List<String> tags;
    private Integer merchantAccountNumber;

    @Override
    public String toString() {
        return "ProductOptionDto{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", permittedValues=" + permittedValues +
                ", tags=" + tags +
                ", merchantAccountNumber=" + merchantAccountNumber +
                '}';
    }

    //private List<IndividualProductOptionDto> individualProductOptions;

}
