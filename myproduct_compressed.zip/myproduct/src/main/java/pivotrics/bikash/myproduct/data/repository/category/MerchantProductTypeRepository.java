package pivotrics.bikash.myproduct.data.repository.category;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import pivotrics.bikash.myproduct.data.entity.category.Merchant_product_type;


@Repository
public interface MerchantProductTypeRepository extends JpaRepository<Merchant_product_type, Integer> {
}
