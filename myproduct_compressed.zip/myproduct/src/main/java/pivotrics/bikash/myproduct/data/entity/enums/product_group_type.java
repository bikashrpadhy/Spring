package pivotrics.bikash.myproduct.data.entity.enums;
import lombok.Getter;

@Getter
public enum product_group_type {

    INDIVIDUAL_PRODUCT("Individual Product"),
    PRODUCT_LIST("Product List"),
    PRODUCT_COMBO("Product Combo"),
    PRODUCT_CATEGORY("Product Category"),
    BRAND("Brand");

    private final String displayName;

    // Constructor to set the display name for each enum constant
    product_group_type(String displayName) {
        this.displayName = displayName;
    }

    // Static method to get the enum constant from a display name
    public static product_group_type fromDisplayName(String displayName) {
        for (product_group_type type : product_group_type.values()) {
            if (type.getDisplayName().equalsIgnoreCase(displayName)) {
                return type;
            }
        }
        throw new IllegalArgumentException("No enum constant with display name " + displayName);
    }
}
