package pivotrics.bikash.myproduct.data.service.product;

import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import pivotrics.bikash.myproduct.api.dto.MerchantProductVariationDto;
import pivotrics.bikash.myproduct.api.mapper.product.MerchantProductVariationMapper;
import pivotrics.bikash.myproduct.data.entity.category.Google_product_category;
import pivotrics.bikash.myproduct.data.entity.product.Merchant_products;
import pivotrics.bikash.myproduct.data.entity.product.Merchant_product_variation;
import pivotrics.bikash.myproduct.data.entity.promo.Merchant_product_list;
import pivotrics.bikash.myproduct.data.repository.product.MerchantProductRepository;
import pivotrics.bikash.myproduct.data.repository.product.MerchantProductVariationRepository;

import java.util.List;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class MerchantProductVariationService {

    private final MerchantProductVariationRepository variationRepository;
    private final MerchantProductRepository productRepository;
    private final MerchantProductVariationMapper variationMapper;

//    @Autowired
//    public MerchantProductVariationService(MerchantProductVariationRepository variationRepository,
//                                           MerchantProductRepository productRepository,
//                                           MerchantProductVariationMapper variationMapper) {
//        this.variationRepository = variationRepository;
//        this.productRepository = productRepository;
//        this.variationMapper = variationMapper;
//    }

    public MerchantProductVariationDto createMerchantProductVariation(MerchantProductVariationDto dto) {
        log.info("Creating MerchantProductVariation with data: {}", dto);

        // Fetch the merchant product by ID
        Merchant_products merchantProduct = productRepository.findById(dto.getMerchantProduct())
                .orElseThrow(() -> {
                    log.error("MerchantProduct with ID {} not found", dto.getMerchantProduct());
                    return new RuntimeException("MerchantProduct not found");
                });

        // Map DTO to entity
        Merchant_product_variation entity = variationMapper.toEntity(dto);
        entity.setMerchantProduct(merchantProduct);  // Set the MerchantProduct reference

        // Save entity to the repository
        Merchant_product_variation savedEntity = variationRepository.save(entity);

        log.info("Successfully created MerchantProductVariation with ID {}", savedEntity.getId());
        return variationMapper.toDto(savedEntity);
    }

    public List<MerchantProductVariationDto> getAllVariations() {
        log.info("Fetching all MerchantProductVariations");
        List<Merchant_product_variation> variationList= variationRepository.findAll();
        return variationList.stream()
                .map(variationMapper::toDto)
                .collect(Collectors.toList());
    }//not working

    public MerchantProductVariationDto getVariationById(Integer id) {
        log.info("Fetching MerchantProductVariation with ID {}", id);
        return variationRepository.findById(id)
                .map(variationMapper::toDto)
                .orElseThrow(() -> {
                    log.error("MerchantProductVariation with ID {} not found", id);
                    return new RuntimeException("Variation not found");
                });
    }

    public MerchantProductVariationDto updateProductVariation(Integer id, MerchantProductVariationDto dto) {
        log.info("Updating MerchantProductVariation with ID: {}", id);

        // Fetch the existing entity
        Merchant_product_variation existingVariation = variationRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("MerchantProductVariation not found with id " + id));

        // Update the fields of the existing entity with new DTO data
        log.info("Mapping fields from DTO to existing entity for ID: {}", id);
        Merchant_product_variation updated_entity = variationMapper.toEntity(dto);

        // Handle references (if applicable)
        if (dto.getMerchantProduct() != null) {
            Merchant_products merchantProduct= productRepository.findById(dto.getMerchantProduct())
                    .orElseThrow(() -> new RuntimeException("MerchantProduct not found with id " + dto.getMerchantProduct()));

            updated_entity.setMerchantProduct(merchantProduct);
        }

        // Save the updated entity back to the repository
        Merchant_product_variation updatedEntity = variationRepository.save(updated_entity);
        log.info("Successfully updated MerchantProductVariation with ID: {}", updatedEntity.getId());

        // Convert the updated entity to a DTO and return it
        return variationMapper.toDto(updatedEntity);
    }


    public void deleteVariation(Integer id) {
        log.info("Deleting MerchantProductVariation with ID {}", id);
        if (!variationRepository.existsById(id)) {
            log.error("MerchantProductVariation with ID {} does not exist", id);
            throw new RuntimeException("Variation not found");
        }
        variationRepository.deleteById(id);
        log.info("Successfully deleted MerchantProductVariation with ID {}", id);
    }
}
