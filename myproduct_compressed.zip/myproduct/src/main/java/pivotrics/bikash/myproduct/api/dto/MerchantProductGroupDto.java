package pivotrics.bikash.myproduct.api.dto;



import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.List;

@Getter
@Setter
public class MerchantProductGroupDto implements Serializable {
    private Integer id;
    private String groupDescription;
    private String groupName;
    //private ProductGroupType productGroupType;
    private String productGroupType;
    private List<Integer> individualProductIds;
    private Boolean isEnabled;
    private Boolean isActive;
    private Integer merchantAccountNumber;
    private List<Integer> productComboIds;
    private ZonedDateTime createdOn;
    private ZonedDateTime lastUpdated;

    private List<GoogleProductCategoryDto> googleProductCategoriesDto;
    private List<ShopifyProductCategoryDto> shopifyProductCategoriesDto;
    private List<MerchantProductTypeDto> merchantProductTypeDtos;
    private MerchantProductBrandDto merchantProductBrandDto;
    private MerchantProductListDto merchantProductListDto;
    private ProductGroupCriteriaDto productGroupCriteriaDto;
    private ProductGroupLimitingFactorDto productGroupLimitingFactorDto;
}