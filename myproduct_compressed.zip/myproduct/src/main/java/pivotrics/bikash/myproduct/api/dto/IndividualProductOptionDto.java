package pivotrics.bikash.myproduct.api.dto;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class IndividualProductOptionDto implements Serializable {
    private static final long serialVersionUID = 1L;

    private Integer id;
    private String value;
    private String name;
    private Integer merchantProduct;
    private Integer productOption;

    // getters and setters
}