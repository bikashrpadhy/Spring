// working

package pivotrics.bikash.myproduct.api.controller.product;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pivotrics.bikash.myproduct.api.dto.ProductOptionDto;
import pivotrics.bikash.myproduct.data.service.product.ProductOptionService;

import java.util.List;

@RestController
@RequestMapping("/product-options")
public class ProductOptionController {

    private static final Logger logger = LoggerFactory.getLogger(ProductOptionController.class);

    @Autowired
    private ProductOptionService productOptionService;

    @PostMapping
    public ResponseEntity<ProductOptionDto> createProductOption(@RequestBody ProductOptionDto productOptionDto) {
        logger.info("Request to create product option: {}", productOptionDto);
        ProductOptionDto savedProductOption = productOptionService.saveProductOption(productOptionDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedProductOption);
    }

    @GetMapping
    public ResponseEntity<List<ProductOptionDto>> getAllProductOptions() {
        logger.info("Request to fetch all product options");
        List<ProductOptionDto> productOptions = productOptionService.getAllProductOptions();
        return ResponseEntity.ok(productOptions);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ProductOptionDto> getProductOptionById(@PathVariable Integer id) {
        logger.info("Request to fetch product option with id: {}", id);
        ProductOptionDto productOptionDto = productOptionService.getProductOptionById(id);
        return ResponseEntity.ok(productOptionDto);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ProductOptionDto> updateProductOption(@PathVariable Integer id, @RequestBody ProductOptionDto productOptionDto) {
        logger.info("Request to update product option with id: {}", id);
//        System.out.println(productOptionDto.toString());
        ProductOptionDto updatedProductOption = productOptionService.updateProductOption(id, productOptionDto);
        return ResponseEntity.ok(updatedProductOption);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProductOption(@PathVariable Integer id) {
        logger.info("Request to delete product option with id: {}", id);
        productOptionService.deleteProductOption(id);
        return ResponseEntity.noContent().build();
    }
}
