package pivotrics.bikash.myproduct.data.service.promo;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import pivotrics.bikash.myproduct.api.dto.MerchantProductListDto;

import pivotrics.bikash.myproduct.api.mapper.promo.MerchantProductListMapper;
import pivotrics.bikash.myproduct.data.entity.promo.Merchant_product_list;
import pivotrics.bikash.myproduct.data.repository.promo.MerchantProductListRepository;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class  MerchantProductListService {

    private final MerchantProductListRepository productListRepository;
    private final MerchantProductListMapper productListMapper;

    public MerchantProductListDto createProductList(MerchantProductListDto productListDto) {
        log.info("Creating MerchantProductList: {}", productListDto.getListName());
        Merchant_product_list productList = productListMapper.toEntity(productListDto);
        productList.setCreatedOn(ZonedDateTime.now()); // Set creation time
        productList.setLastUpdated(ZonedDateTime.now()); // Set last updated time
        productList = productListRepository.save(productList);
        return productListMapper.toDto(productList);
    }

    public MerchantProductListDto updateProductList(Integer id, MerchantProductListDto productListDto) {
        log.info("Updating MerchantProductList with ID: {}", id);
        Merchant_product_list existingProductList = productListRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("MerchantProductList not found with ID: " + id));

        productListMapper.toEntity(productListDto); // Updates the fields
        existingProductList.setLastUpdated(ZonedDateTime.now()); // Set last updated time
        existingProductList = productListRepository.save(existingProductList);

        return productListMapper.toDto(existingProductList);
    }

    public void deleteProductList(Integer id) {
        log.info("Deleting MerchantProductList with ID: {}", id);
        productListRepository.deleteById(id);
    }

    public MerchantProductListDto getProductListById(Integer id) {
        log.info("Fetching MerchantProductList with ID: {}", id);
        Merchant_product_list productList = productListRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("MerchantProductList not found with ID: " + id));

        return productListMapper.toDto(productList);
    }

    public List<MerchantProductListDto> getAllProductLists() {
        log.info("Fetching all MerchantProductLists");
        List<Merchant_product_list> productLists = productListRepository.findAll();

        return productLists.stream()
                .map(productListMapper::toDto)
                .collect(Collectors.toList());
    }
}
