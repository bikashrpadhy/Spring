package pivotrics.bikash.myproduct.data.entity.product;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import pivotrics.bikash.myproduct.data.entity.category.Google_product_category;
import pivotrics.bikash.myproduct.data.entity.category.Merchant_product_type;
import pivotrics.bikash.myproduct.data.entity.category.Shopify_product_category;
import pivotrics.bikash.myproduct.data.entity.enums.MerchantProductClassification;

import java.io.Serial;
import java.io.Serializable;
import java.time.OffsetDateTime;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "merchant_products")
public class Merchant_products implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @Column(name = "sku")
    private String sku;

    @Column(name = "product_name", nullable = false)
    private String product_name;

    @Column(name = "tags")
    private String tags;

    @Column(name = "merchant_account_number", nullable = false)
    private Integer merchant_account_number;


    @Column(name = "merchant_department_id", nullable = false)
    private Integer[] merchant_department_id;

    @Column(name = "upc", nullable = false)
    private Character upc;

    @Enumerated(EnumType.STRING)
    @Column(name = "product_class", nullable = false)
    private MerchantProductClassification product_class;

    @Column(name = "parent_product_id")
    private Integer parent_product_id;

    @Column(name = "selling_price")
    private Integer selling_price;

    @Column(name = "lowest_discounted_price")
    private Integer lowest_discounted_price;

    @Column(name = "force_exclusion_from_promotion")
    private Boolean force_exclusion_from_promotion;

    @Column(name = "tax_applicable")
    private Boolean tax_applicable;

    @Column(name = "returnable")
    private Boolean returnable;

    @Column(name = "is_enabled")
    private Boolean is_enabled;

    @Column(name = "shipping_required")
    private Boolean shipping_required;

    @Column(name = "created_on")
    private OffsetDateTime created_on; // can be zoned date time - better I feel

    @Column(name = "last_updated")
    private OffsetDateTime last_updated;

    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "id_merchant_tax_config", nullable = false)
    private Merchant_tax_config id_merchant_tax_config;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_merchant_product_brand")
    private Merchant_product_brand id_merchant_product_brand;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_merchant_product_type")
    private Merchant_product_type id_merchant_product_type;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_google_product_category_id")
    private Google_product_category id_google_product_category;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_shopify_product_category_id")
    private Shopify_product_category id_shopify_product_category;

}