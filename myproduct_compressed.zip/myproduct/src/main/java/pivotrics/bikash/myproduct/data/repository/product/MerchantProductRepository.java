package pivotrics.bikash.myproduct.data.repository.product;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import pivotrics.bikash.myproduct.data.entity.product.Merchant_products;

@Repository
public interface MerchantProductRepository extends JpaRepository<Merchant_products, Integer> {
}
