package pivotrics.bikash.myproduct.data.entity.product;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serial;
import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "merchant_tax_config")
public class Merchant_tax_config implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @Column(name = "tax_description")
    private String taxDescription;

    @Column(name = "tax_percentage", nullable = false)
    private Short taxPercentage;

    @Column(name = "hsn_code", nullable = false)
    private String hsnCode;

    @Column(name = "merchant_account_number", nullable = false)
    private Integer merchantAccountNumber;

//    @OneToMany(mappedBy = "id_merchant_tax_config", cascade = CascadeType.ALL, orphanRemoval = true)
//    private List<Merchant_products> merchantProducts = new ArrayList<>();


}