package pivotrics.bikash.myproduct.data.service.product;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import pivotrics.bikash.myproduct.data.entity.product.Merchant_product_brand;
import pivotrics.bikash.myproduct.data.repository.product.MerchantProductBrandRepository;
import pivotrics.bikash.myproduct.api.dto.MerchantProductBrandDto;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class MerchantProductBrandService {

    @Autowired
    private MerchantProductBrandRepository repository;

    @Autowired
    private ModelMapper modelMapper;

    @Transactional
    public MerchantProductBrandDto saveMerchantProductBrand(MerchantProductBrandDto dto) {
        Merchant_product_brand entity = modelMapper.map(dto, Merchant_product_brand.class);
        Merchant_product_brand savedEntity = repository.save(entity);
        return modelMapper.map(savedEntity, MerchantProductBrandDto.class);
    }

    public List<MerchantProductBrandDto> getAllMerchantProductBrands() {
        return repository.findAll().stream()
                .map(entity -> modelMapper.map(entity, MerchantProductBrandDto.class))
                .collect(Collectors.toList());
    }

    public MerchantProductBrandDto getMerchantProductBrandById(Integer id) {
        Merchant_product_brand entity = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Merchant_product_brand not found with id " + id));
        return modelMapper.map(entity, MerchantProductBrandDto.class);
    }

    @Transactional
    public void deleteMerchantProductBrand(Integer id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
        } else {
            throw new RuntimeException("Merchant_product_brand not found with id " + id);
        }
    }

    @Transactional
    public MerchantProductBrandDto updateMerchantProductBrand(Integer id, MerchantProductBrandDto dto) {
        if (repository.existsById(id)) {
            dto.setId(id);
            Merchant_product_brand entity = modelMapper.map(dto, Merchant_product_brand.class);
            Merchant_product_brand updatedEntity = repository.save(entity);
            return modelMapper.map(updatedEntity, MerchantProductBrandDto.class);
        } else {
            throw new RuntimeException("Merchant_product_brand not found with id " + id);
        }
    }
}
