package pivotrics.bikash.myproduct.api.mapper.product;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;
import pivotrics.bikash.myproduct.api.dto.IndividualProductOptionDto;
import pivotrics.bikash.myproduct.data.entity.product.Individual_product_option;

@Mapper(componentModel = "spring")
public interface IndividualProductOptionMapper {

    IndividualProductOptionMapper INSTANCE = Mappers.getMapper(IndividualProductOptionMapper.class);

    @Mapping(source = "merchantProduct", target = "merchantProduct.id")
    @Mapping(source = "productOption", target = "productOption.id")
    Individual_product_option toEntity(IndividualProductOptionDto dto);

    @Mapping(source = "merchantProduct.id", target = "merchantProduct")
    @Mapping(source = "productOption.id", target = "productOption")
    IndividualProductOptionDto toDto(Individual_product_option entity);
}
