// ready.

package pivotrics.bikash.myproduct.api.controller.product;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pivotrics.bikash.myproduct.data.service.product.MerchantTaxConfigService;
import pivotrics.bikash.myproduct.api.dto.MerchantTaxConfigDto;

import java.util.List;

@RestController
@RequestMapping("/merchant-tax-config")
public class MerchantTaxConfigController {

    private static final Logger logger = LoggerFactory.getLogger(MerchantTaxConfigController.class);

    @Autowired
    private MerchantTaxConfigService service;

    @PostMapping
    public ResponseEntity<MerchantTaxConfigDto> createMerchantTaxConfig(@RequestBody MerchantTaxConfigDto merchantTaxConfigDto) {
        logger.info("Request to create merchant tax config: {}", merchantTaxConfigDto);
        MerchantTaxConfigDto savedDto = service.saveMerchantTaxConfig(merchantTaxConfigDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedDto);
    }

    @GetMapping
    public ResponseEntity<List<MerchantTaxConfigDto>> getAllMerchantTaxConfigs() {
        logger.info("Request to fetch all merchant tax configs");
        List<MerchantTaxConfigDto> taxConfigs = service.getAllMerchantTaxConfigs();
        return ResponseEntity.ok(taxConfigs);
    }

    @GetMapping("/{id}")
    public ResponseEntity<MerchantTaxConfigDto> getMerchantTaxConfigById(@PathVariable Integer id) {
        logger.info("Request to fetch merchant tax config with id: {}", id);
        MerchantTaxConfigDto taxConfigDto = service.getMerchantTaxConfigById(id);
        return ResponseEntity.ok(taxConfigDto);
    }

    @PutMapping("/{id}")
    public ResponseEntity<MerchantTaxConfigDto> updateMerchantTaxConfig(@PathVariable Integer id, @RequestBody MerchantTaxConfigDto merchantTaxConfigDto) {
        logger.info("Request to update merchant tax config with id: {}", id);
        MerchantTaxConfigDto updatedDto = service.updateMerchantTaxConfig(id, merchantTaxConfigDto);
        return ResponseEntity.ok(updatedDto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMerchantTaxConfig(@PathVariable Integer id) {
        logger.info("Request to delete merchant tax config with id: {}", id);
        service.deleteMerchantTaxConfig(id);
        return ResponseEntity.noContent().build();
    }
}
