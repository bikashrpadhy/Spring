// its working
package pivotrics.bikash.myproduct.api.controller.product;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pivotrics.bikash.myproduct.api.dto.MerchantProductVariationDto;
import pivotrics.bikash.myproduct.data.service.product.MerchantProductVariationService;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/merchant-product-variations")
public class MerchantProductVariationController {

    @Autowired
    private MerchantProductVariationService service;

    @PostMapping
    public ResponseEntity<MerchantProductVariationDto> createProductVariation(@RequestBody MerchantProductVariationDto dto) {
        log.info("Creating a new product variation");
        MerchantProductVariationDto createdDto = service.createMerchantProductVariation(dto);
        log.info("Successfully created product variation with ID: {}", createdDto.getId());
        return new ResponseEntity<>(createdDto, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<MerchantProductVariationDto>> getAllProductVariations() {
        log.info("Fetching all product variations");
        List<MerchantProductVariationDto> dtos = service.getAllVariations();
        log.info("Successfully fetched {} product variations", dtos.size());
        return new ResponseEntity<>(dtos, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<MerchantProductVariationDto> getProductVariationById(@PathVariable Integer id) {
        log.info("Fetching product variation with ID: {}", id);
        MerchantProductVariationDto dto = service.getVariationById(id);
        log.info("Successfully fetched product variation with ID: {}", id);
        return new ResponseEntity<>(dto, HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<MerchantProductVariationDto> updateProductVariation(
            @PathVariable Integer id,
            @RequestBody MerchantProductVariationDto dto) {
        log.info("Updating product variation with ID: {}", id);
        MerchantProductVariationDto updatedDto = service.updateProductVariation(id, dto);
        log.info("Successfully updated product variation with ID: {}", updatedDto.getId());
        return new ResponseEntity<>(updatedDto, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProductVariation(@PathVariable Integer id) {
        log.info("Deleting product variation with ID: {}", id);
        service.deleteVariation(id);
        log.info("Successfully deleted product variation with ID: {}", id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
