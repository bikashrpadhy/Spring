package pivotrics.bikash.myproduct.data.entity.product;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.io.Serial;
import java.io.Serializable;

@Getter
@Setter
@Entity
@Table(name = "merchant_product_variation")
public class Merchant_product_variation implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @Column(name = "variationName")
    private String variationName;

    @Column(name = "merchantAccountNumber")
    private Integer merchantAccountNumber;

    @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "id_merchantProducts", unique = true)
    private Merchant_products merchantProduct;

}