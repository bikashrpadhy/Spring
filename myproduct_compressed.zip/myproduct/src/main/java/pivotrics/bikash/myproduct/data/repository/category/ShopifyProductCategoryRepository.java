package pivotrics.bikash.myproduct.data.repository.category;

import org.springframework.data.jpa.repository.JpaRepository;
import pivotrics.bikash.myproduct.data.entity.category.Shopify_product_category;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface ShopifyProductCategoryRepository extends JpaRepository<Shopify_product_category, Integer> {

    List<Shopify_product_category> findByshopifyParentCategory(Shopify_product_category parent);
//    shopifyParentCategory

}
