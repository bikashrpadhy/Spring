package pivotrics.bikash.myproduct.data.service.product;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.modelmapper.ModelMapper;
import pivotrics.bikash.myproduct.api.dto.ProductOptionDto;
import pivotrics.bikash.myproduct.data.entity.product.Product_option;
import pivotrics.bikash.myproduct.data.repository.product.ProductOptionRepository;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProductOptionService {

    private static final Logger logger = LoggerFactory.getLogger(ProductOptionService.class);

    @Autowired
    private ProductOptionRepository repository;

    @Autowired
    private ModelMapper modelMapper; // Add ModelMapper for mapping between entity and DTO

    @Transactional
    public ProductOptionDto saveProductOption(ProductOptionDto productOptionDto) {
        logger.info("Saving product option: {}", productOptionDto);
        Product_option productOption = modelMapper.map(productOptionDto, Product_option.class);
        Product_option savedEntity = repository.save(productOption);
        return modelMapper.map(savedEntity, ProductOptionDto.class);
    }

    public List<ProductOptionDto> getAllProductOptions() {
        logger.info("Fetching all product options");
        return repository.findAll().stream()
                .map(entity -> modelMapper.map(entity, ProductOptionDto.class))
                .collect(Collectors.toList());
    }

    public ProductOptionDto getProductOptionById(Integer id) {
        logger.info("Fetching product option with id: {}", id);
        Product_option entity = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Product_option not found with id " + id));
        return modelMapper.map(entity, ProductOptionDto.class);
    }

    @Transactional
    public void deleteProductOption(Integer id) {
        try {
            logger.info("Deleting product option with id: {}", id);
            repository.deleteById(id);
        } catch (EmptyResultDataAccessException e) {
            logger.error("Failed to delete product option with id: {}. It does not exist.", id);
            throw new RuntimeException("Product_option not found with id " + id);
        }
    }

    @Transactional
    public ProductOptionDto updateProductOption(Integer id, ProductOptionDto updatedProductOptionDto) {
        logger.info("Updating product option with id: {}", id);
//        logger.info(updatedProductOptionDto.toString());
        System.out.println("Service: "+ updatedProductOptionDto.toString());

        if (repository.existsById(id)) {
            Product_option updatedProductOption = modelMapper.map(updatedProductOptionDto, Product_option.class);
            updatedProductOption.setId(id);
            Product_option updatedEntity = repository.save(updatedProductOption);
            return modelMapper.map(updatedEntity, ProductOptionDto.class);
        } else {
            throw new RuntimeException("Product_option not found with id " + id);
        }
    }
}
