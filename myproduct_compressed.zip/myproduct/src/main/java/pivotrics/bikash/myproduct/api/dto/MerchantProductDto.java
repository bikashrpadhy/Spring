package pivotrics.bikash.myproduct.api.dto;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.List;

@Getter
@Setter
public class MerchantProductDto implements Serializable {
    private static final long serialVersionUID = 1L;

    private Integer id;
    private String sku;
    private List<String> tags;
    private String upc;
    private String productName;
    //private MerchantProductClassification productClass;
    private String productClass;
    private Integer parentProductId;
    private Integer merchantAccountNumber;
    private List<Integer> merchantDepartmentId;
    private BigDecimal mrp;
    private BigDecimal sellingPrice;
    private BigDecimal lowestDiscountedPrice;
    private Boolean forceExclusionFromPromotion;
    private Boolean taxApplicable;
    private Integer taxConfigId;
    private Boolean returnable;
    private Boolean shippingRequired;
    private Boolean isEnabled;
    private GoogleProductCategoryDto googleProductCategoryDto;
    private MerchantProductBrandDto merchantProductBrandDto;
    private MerchantProductTypeDto merchantProductTypeDto;
    private MerchantTaxConfigDto merchantTaxConfigDto;
    private ShopifyProductCategoryDto shopifyProductCategoryDto;
    private List<IndividualProductOptionDto> individualProductOptionDtos;
    private MerchantProductVariationDto merchantProductVariationDto;
    private ZonedDateTime createdOn;
    private ZonedDateTime lastUpdated;
}