package pivotrics.bikash.myproduct.data.repository.category;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import pivotrics.bikash.myproduct.data.entity.category.Google_product_category;

@Repository
public interface GoogleProductCategoryRepository extends JpaRepository<Google_product_category, Integer> {
    // Custom query methods if necessary
}
