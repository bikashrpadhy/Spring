package pivotrics.bikash.myproduct;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.Serial;
import java.io.Serializable;

@SpringBootApplication
public class MyproductApplication implements Serializable {

	@Serial
	private static final long serialVersionUID = 1L;

	public static void main(String[] args) {
		SpringApplication.run(MyproductApplication.class, args);
	}

}
