package pivotrics.bikash.myproduct.api.dto;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class ProductGroupCriteriaDto implements Serializable {
    private static final long serialVersionUID = 1L;

    private Integer id;
    private Boolean enableMinProductVarietyCheck;
    private Boolean enableMinQuantityCheck;
    private Integer minProductVariety;
    private Integer minQuantity;
    private MerchantProductGroupDto merchantProductGroup;

    // getters and setters
}