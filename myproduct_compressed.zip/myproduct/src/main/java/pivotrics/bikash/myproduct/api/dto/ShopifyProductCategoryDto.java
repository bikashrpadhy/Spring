package pivotrics.bikash.myproduct.api.dto;

import lombok.Getter;
import lombok.Setter;
import pivotrics.bikash.myproduct.data.entity.category.Shopify_product_category;

import java.io.Serializable;

@Getter
@Setter
public class ShopifyProductCategoryDto implements Serializable {
    private static final long serialVersionUID = 1L;

    private Integer id;
    private Boolean isEnabled;
    private Integer merchantAccountNumber;
    private String name;
    private Short categoryCode;
    private Integer level;
    private String fullQualifiedName;
    private Integer shopifyParentCategory; // Reference to parent category id

    //private GoogleProductCategoryDTO parentGoogleProductCategory;

}