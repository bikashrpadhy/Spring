package pivotrics.bikash.myproduct.data.service.category;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import pivotrics.bikash.myproduct.data.entity.category.Merchant_product_type;
import  pivotrics.bikash.myproduct.data.repository.category.MerchantProductTypeRepository;
import pivotrics.bikash.myproduct.api.dto.MerchantProductTypeDto;


import java.util.List;
import java.util.stream.Collectors;

@Service
public class MerchantProductTypeService {

    private static final Logger logger = LoggerFactory.getLogger(MerchantProductTypeService.class);

    @Autowired
    private MerchantProductTypeRepository repository;

    @Autowired
    private ModelMapper modelMapper;

    @Transactional
    public MerchantProductTypeDto createMerchantProductType(MerchantProductTypeDto dto) {
        logger.info("Creating MerchantProductType: {}", dto);
        Merchant_product_type entity = modelMapper.map(dto, Merchant_product_type.class);
        Merchant_product_type savedEntity = repository.save(entity);
        return modelMapper.map(savedEntity, MerchantProductTypeDto.class);
    }

    public List<MerchantProductTypeDto> getAllMerchantProductTypes() {
        logger.info("Fetching all MerchantProductTypes");
        return repository.findAll().stream()
                .map(entity -> modelMapper.map(entity, MerchantProductTypeDto.class))
                .collect(Collectors.toList());
    }

    public MerchantProductTypeDto getMerchantProductTypeById(Integer id) {
        logger.info("Fetching MerchantProductType with id: {}", id);
        Merchant_product_type entity = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("MerchantProductType not found with id " + id));
        return modelMapper.map(entity, MerchantProductTypeDto.class);
    }

    @Transactional
    public MerchantProductTypeDto updateMerchantProductType(Integer id, MerchantProductTypeDto dto) {
        logger.info("Updating MerchantProductType with id: {}", id);
        if (repository.existsById(id)) {
            dto.setId(id);
            Merchant_product_type entity = modelMapper.map(dto, Merchant_product_type.class);
            Merchant_product_type updatedEntity = repository.save(entity);
            return modelMapper.map(updatedEntity, MerchantProductTypeDto.class);
        } else {
            throw new RuntimeException("MerchantProductType not found with id " + id);
        }
    }

    @Transactional
    public void deleteMerchantProductType(Integer id) {
        try {
            logger.info("Deleting MerchantProductType with id: {}", id);
            repository.deleteById(id);
        } catch (Exception e) {
            logger.error("Failed to delete MerchantProductType with id: {}. It does not exist.", id);
            throw new RuntimeException("MerchantProductType not found with id " + id);
        }
    }
}
