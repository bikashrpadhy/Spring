package pivotrics.bikash.myproduct.api.dto;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;

@Getter
@Setter
public class ProductGroupLimitingFactorDto implements Serializable {
    private static final long serialVersionUID = 1L;

    private Integer id;
    private Integer cummulativeQuantityAllowed;
    private Boolean enableFurtherDiscountAtCartLevelWhenAvailable;
    private Float maxAdditionalDiscountInPercentageAtCartLevel;
    private Integer maxAllowedQuantityPerTxn;
    private BigDecimal maxDiscountOnSubtotalPerTxn;
    private Integer maxQuantityPerCustomer;
    private MerchantProductGroupDto merchantProductGroup;

    // getters and setters
}