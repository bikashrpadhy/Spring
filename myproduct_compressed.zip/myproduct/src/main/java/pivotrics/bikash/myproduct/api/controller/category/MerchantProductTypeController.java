// working

package pivotrics.bikash.myproduct.api.controller.category;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import pivotrics.bikash.myproduct.api.dto.MerchantProductTypeDto;
import pivotrics.bikash.myproduct.data.service.category.MerchantProductTypeService;
import java.util.List;

@RestController
@RequestMapping("/merchant-product-types")
public class MerchantProductTypeController {

    private static final Logger logger = LoggerFactory.getLogger(MerchantProductTypeController.class);

    @Autowired
    private MerchantProductTypeService service;

    @PostMapping
    public ResponseEntity<MerchantProductTypeDto> createMerchantProductType(@RequestBody MerchantProductTypeDto dto) {
        logger.info("Received request to create MerchantProductType: {}", dto);
        MerchantProductTypeDto createdDto = service.createMerchantProductType(dto);
        return ResponseEntity.ok(createdDto);
    }

    @GetMapping
    public ResponseEntity<List<MerchantProductTypeDto>> getAllMerchantProductTypes() {
        logger.info("Received request to fetch all MerchantProductTypes");
        List<MerchantProductTypeDto> dtos = service.getAllMerchantProductTypes();
        return ResponseEntity.ok(dtos);
    }

    @GetMapping("/{id}")
    public ResponseEntity<MerchantProductTypeDto> getMerchantProductTypeById(@PathVariable Integer id) {
        logger.info("Received request to fetch MerchantProductType with id: {}", id);
        MerchantProductTypeDto dto = service.getMerchantProductTypeById(id);
        return ResponseEntity.ok(dto);
    }

    @PutMapping("/{id}")
    public ResponseEntity<MerchantProductTypeDto> updateMerchantProductType(
            @PathVariable Integer id,
            @RequestBody MerchantProductTypeDto dto) {
        logger.info("Received request to update MerchantProductType with id: {}", id);
        MerchantProductTypeDto updatedDto = service.updateMerchantProductType(id, dto);
        return ResponseEntity.ok(updatedDto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMerchantProductType(@PathVariable Integer id) {
        logger.info("Received request to delete MerchantProductType with id: {}", id);
        service.deleteMerchantProductType(id);
        return ResponseEntity.noContent().build();
    }
}
