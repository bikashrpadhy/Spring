// "createdOn": "2024-09-16T12:00:00+01:00[Europe/Paris]"

package pivotrics.bikash.myproduct.api.controller.promo;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pivotrics.bikash.myproduct.api.dto.MerchantProductListDto;
import pivotrics.bikash.myproduct.data.service.promo.MerchantProductListService;

import java.util.List;

@RestController
@RequestMapping("/merchant-product-lists")
@RequiredArgsConstructor
@Slf4j
public class MerchantProductListController {

    private final MerchantProductListService productListService;

    @PostMapping
    public ResponseEntity<MerchantProductListDto> createProductList(@RequestBody MerchantProductListDto productListDto) {
        log.info("Request to create MerchantProductList");
        MerchantProductListDto createdProductList = productListService.createProductList(productListDto);
        return ResponseEntity.ok(createdProductList);
    }

    @PutMapping("/{id}")
    public ResponseEntity<MerchantProductListDto> updateProductList(@PathVariable Integer id, @RequestBody MerchantProductListDto productListDto) {
        log.info("Request to update MerchantProductList with ID: {}", id);
        MerchantProductListDto updatedProductList = productListService.updateProductList(id, productListDto);
        return ResponseEntity.ok(updatedProductList);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProductList(@PathVariable Integer id) {
        log.info("Request to delete MerchantProductList with ID: {}", id);
        productListService.deleteProductList(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{id}")
    public ResponseEntity<MerchantProductListDto> getProductListById(@PathVariable Integer id) {
        log.info("Request to get MerchantProductList with ID: {}", id);
        MerchantProductListDto productList = productListService.getProductListById(id);
        return ResponseEntity.ok(productList);
    }

    @GetMapping
    public ResponseEntity<List<MerchantProductListDto>> getAllProductLists() {
        log.info("Request to get all MerchantProductLists");
        List<MerchantProductListDto> productLists = productListService.getAllProductLists();
        return ResponseEntity.ok(productLists);
    }
}
