// working, needs logging
package pivotrics.bikash.myproduct.api.controller.product;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

import pivotrics.bikash.myproduct.api.dto.MerchantProductBrandDto;
import pivotrics.bikash.myproduct.data.service.product.MerchantProductBrandService;

@RestController
@RequestMapping("/merchant-product-brands")
public class MerchantProductBrandController {

    @Autowired
    private MerchantProductBrandService service;

    @PostMapping
    public ResponseEntity<MerchantProductBrandDto> createMerchantProductBrand(@RequestBody MerchantProductBrandDto dto) {
        MerchantProductBrandDto createdDto = service.saveMerchantProductBrand(dto);
        return new ResponseEntity<>(createdDto, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<MerchantProductBrandDto>> getAllMerchantProductBrands() {
        List<MerchantProductBrandDto> dtos = service.getAllMerchantProductBrands();
        return new ResponseEntity<>(dtos, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<MerchantProductBrandDto> getMerchantProductBrandById(@PathVariable Integer id) {
        MerchantProductBrandDto dto = service.getMerchantProductBrandById(id);
        return new ResponseEntity<>(dto, HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<MerchantProductBrandDto> updateMerchantProductBrand(
            @PathVariable Integer id,
            @RequestBody MerchantProductBrandDto dto) {
        MerchantProductBrandDto updatedDto = service.updateMerchantProductBrand(id, dto);
        return new ResponseEntity<>(updatedDto, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMerchantProductBrand(@PathVariable Integer id) {
        service.deleteMerchantProductBrand(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
