package pivotrics.bikash.myproduct.data.service.category;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import pivotrics.bikash.myproduct.api.dto.GoogleProductCategoryDto;
import pivotrics.bikash.myproduct.data.entity.category.Google_product_category;
import pivotrics.bikash.myproduct.data.entity.category.Shopify_product_category;
import pivotrics.bikash.myproduct.data.repository.category.GoogleProductCategoryRepository;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class GoogleProductCategoryService {

    private final GoogleProductCategoryRepository categoryRepository;
    private final ModelMapper modelMapper;

    public GoogleProductCategoryDto createCategory(GoogleProductCategoryDto categoryDto) {
        log.info("Creating GoogleProductCategory: {}", categoryDto.getName());
        Google_product_category category = modelMapper.map(categoryDto, Google_product_category.class);

        if (categoryDto.getGoogleParentCategory() != null) {
            Google_product_category parent = categoryRepository.findById(categoryDto.getGoogleParentCategory())
                    .orElseThrow(() -> new RuntimeException("Parent Category not found with id " + categoryDto.getGoogleParentCategory()));
            category.setGoogleParentCategory(parent);
        }

        category = categoryRepository.save(category);
        return modelMapper.map(category, GoogleProductCategoryDto.class);
    }

    public GoogleProductCategoryDto updateCategory(Integer id, GoogleProductCategoryDto categoryDto) {
        log.info("Updating GoogleProductCategory with ID: {}", id);
        Google_product_category existingCategory = categoryRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Google Category not found with id " + id));

        if (categoryDto.getGoogleParentCategory() != null) {
            Google_product_category parent = categoryRepository.findById(categoryDto.getGoogleParentCategory())
                    .orElseThrow(() -> new RuntimeException("Parent Category not found with id " + categoryDto.getGoogleParentCategory()));
            existingCategory.setGoogleParentCategory(parent);
        }

        // Update fields
        existingCategory = categoryRepository.save(existingCategory);
        modelMapper.map(categoryDto, existingCategory);
        return modelMapper.map(existingCategory, GoogleProductCategoryDto.class);
    }

    public void deleteCategory(Integer id) {
        log.info("Deleting GoogleProductCategory with ID: {}", id);
        categoryRepository.deleteById(id);
    }

    public GoogleProductCategoryDto getCategoryById(Integer id) {
        log.info("Fetching GoogleProductCategory with ID: {}", id);
        Google_product_category category = categoryRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Google Category not found with id " + id));

        return modelMapper.map(category, GoogleProductCategoryDto.class);
    }

    public List<GoogleProductCategoryDto> getAllCategories() {
        log.info("Fetching all GoogleProductCategories");
        List<Google_product_category> categories = categoryRepository.findAll();

        return categories.stream()
                .map(category -> modelMapper.map(category, GoogleProductCategoryDto.class))
                .collect(Collectors.toList());
    }
}
