package pivotrics.bikash.myproduct.data.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import pivotrics.bikash.myproduct.data.entity.enums.merchant_product_category_choice;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "merchant_catalog_config")
public class Merchant_catalog_config {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @Column(name = "merchant_account_number")
    private Integer merchant_account_number;

    @Column(name = "max_allowed_product")
    private Short max_allowed_product;

    @Column(name = "max_allowed_type")
    private Short max_allowed_type;

    @Enumerated(EnumType.STRING)
    @Column(name = "merchant_product_category_choice")
    private merchant_product_category_choice categories_choice;

    @Column(name = "max_allowed_product_lists")
    private Short max_allowed_product_lists;

    @Column(name = "max_allowed_enabled_product_lists")
    private Short max_allowed_enabled_product_lists;

    @Column(name = "max_allowed_products_in_product_list")
    private Short max_allowed_products_in_product_list;

    @Column(name = "max_allowed_product_group")
    private Short max_allowed_product_group;

    @Column(name = "max_allowed_enabled_product_groups")
    private Short max_allowed_enabled_product_groups;

    @Column(name = "max_categories_in_product_group")
    private Short max_categories_in_product_group;

    @Column(name = "max_product_types_in_product_group")
    private Short max_product_types_in_product_group;

    @Column(name = "max_products_in_combo_product_group")
    private Short max_products_in_combo_product_group;

    @Column(name = "max_individual_products_in_product_group")
    private Short max_individual_products_in_product_group;


}